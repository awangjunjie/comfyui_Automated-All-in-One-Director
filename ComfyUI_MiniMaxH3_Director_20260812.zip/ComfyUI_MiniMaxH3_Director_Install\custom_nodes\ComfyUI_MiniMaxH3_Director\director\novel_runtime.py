"""Novel chapter pipeline: import → chapters → storyboard → global assets → r2v prepare."""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import re
import time
import uuid
import zipfile
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

import folder_paths

log = logging.getLogger("ComfyUI-MiniMaxH3-Director.novel")

CHAPTER_RE = re.compile(
    r"(?m)^(?:\s*)(?:"
    r"第[零〇一二三四五六七八九十百千万两0-9]+章"
    r"|Chapter\s+\d+"
    r"|CHAPTER\s+\d+"
    r")[^\n]{0,80}$"
)
CAST_LINE_RE = re.compile(
    r"(?im)^\s*(?:出场|CAST|角色|人物|场景名?|地点|场所|LOCATION)\s*[:：]\s*(.+)$"
)
NAME_SPLIT_RE = re.compile(r"[,，、/;；|\s]+")
_LOC_LABEL_MARKERS = ("场景", "地点", "场所", "LOCATION", "Location", "location")
_PLACE_SUFFIX_RE = re.compile(
    r"(里|内|中|旁|外|前|后|边|附近|门口|角落|一角|这边|那边|之处|地方)$"
)
# MiniMax H3 dialogue blocks: <d>[中文] ……</d>
_DIALOGUE_TAG_RE = re.compile(r"<d>\s*(?:\[[^\]]*\])?\s*(.*?)\s*</d>", re.I | re.S)
# Mandarin conversational rate (~chars/sec) + acting buffer for duration fit
_NOVEL_SPEECH_CHARS_PER_SEC = 3.4
_NOVEL_SPEECH_ACTING_PAD_SEC = 1.4


def estimate_dialogue_speech_units(prompt: str) -> float:
    """Speech load from <d> blocks: 1 unit ≈ 1 Chinese char; English word ≈ 2.5."""
    units = 0.0
    for m in _DIALOGUE_TAG_RE.finditer(prompt or ""):
        body = m.group(1) or ""
        units += float(len(re.findall(r"[\u4e00-\u9fff]", body)))
        units += 2.5 * float(len(re.findall(r"[A-Za-z]+", body)))
    return units


def fit_novel_shot_duration(
    prompt: str,
    proposed: float | None,
    *,
    d_min: float = 2.0,
    d_max: float = 12.0,
    default: float = 5.0,
) -> float:
    """Clamp proposed duration; bump up when dialogue needs more time than assigned."""
    try:
        base = float(proposed if proposed is not None else default)
    except (TypeError, ValueError):
        base = float(default)
    lo = max(0.5, float(d_min))
    hi = max(lo, float(d_max))
    base = max(lo, min(hi, base))
    units = estimate_dialogue_speech_units(prompt)
    if units <= 0:
        return base
    n_blocks = len(_DIALOGUE_TAG_RE.findall(prompt or ""))
    need = _NOVEL_SPEECH_ACTING_PAD_SEC + units / _NOVEL_SPEECH_CHARS_PER_SEC
    if n_blocks > 1:
        need += 0.35 * (n_blocks - 1)
    # Never shorten below LLM/story pacing; only extend for speech
    return max(lo, min(hi, max(base, need)))


def _clean_place_name(name: str) -> str:
    s = (name or "").strip()
    s = re.sub(r"^[\s「」『』\"'“”]+|[\s「」『』\"'“”。．.!！?？]+$", "", s)
    # peel soft location suffixes a few times（教室里 → 教室）
    for _ in range(3):
        nxt = _PLACE_SUFFIX_RE.sub("", s)
        if nxt == s or len(nxt) < 2:
            break
        s = nxt
    return s.strip()


def _char_ngrams(text: str, n: int = 2) -> set[str]:
    t = text or ""
    if len(t) < n:
        return {t} if t else set()
    return {t[i : i + n] for i in range(len(t) - n + 1)}


def _name_overlap_score(a: str, b: str) -> float:
    """0–1 similarity for Chinese place/character names (exact / contains / n-gram)."""
    x = _clean_place_name(a)
    y = _clean_place_name(b)
    if not x or not y:
        return 0.0
    if x == y:
        return 1.0
    if x in y or y in x:
        return 0.82 + 0.18 * (min(len(x), len(y)) / max(len(x), len(y)))
    sx, sy = set(x), set(y)
    inter = len(sx & sy)
    if inter == 0:
        return 0.0
    jaccard = inter / len(sx | sy)
    bx, by = _char_ngrams(x, 2), _char_ngrams(y, 2)
    bigram = (len(bx & by) / len(bx | by)) if bx and by else 0.0
    return max(0.0, min(1.0, 0.5 * jaccard + 0.5 * bigram))


def _best_substring_coverage(name: str, text: str) -> float:
    """Longest contiguous piece of ``name`` found in ``text`` / len(name)."""
    n = _clean_place_name(name)
    t = text or ""
    if not n or not t:
        return 0.0
    if n in t:
        return 1.0
    best = 0
    for length in range(len(n), 1, -1):
        for i in range(0, len(n) - length + 1):
            sub = n[i : i + length]
            if sub in t:
                best = max(best, length)
                break
        if best:
            break
    return best / len(n) if best else 0.0


def _asset_names(asset: dict[str, Any]) -> list[str]:
    names = [str(asset.get("name") or "").strip()]
    for a in asset.get("aliases") or []:
        s = str(a).strip()
        if s and s not in names:
            names.append(s)
    return [n for n in names if n]


def _learn_asset_alias(asset: dict[str, Any], alias: str) -> None:
    alias = _clean_place_name(alias)
    if not alias or len(alias) < 2:
        return
    canon = str(asset.get("name") or "").strip()
    if not canon or alias == canon:
        return
    # Avoid learning near-identical long descriptive phrases (>16 chars)
    if len(alias) > 16:
        return
    merged = list(asset.get("aliases") or [])
    if alias not in merged:
        merged.append(alias)
        asset["aliases"] = merged[:16]


def _score_asset_for_shot(
    asset: dict[str, Any],
    *,
    prompt: str,
    explicit_names: list[str],
) -> float:
    """How well a library asset fits this shot's 场景/出场 names + prompt body."""
    text = prompt or ""
    best = 0.0
    for n in _asset_names(asset):
        cn = _clean_place_name(n)
        if len(cn) >= 2 and cn in text:
            best = max(best, 0.92 + 0.01 * min(8, len(cn)))
        best = max(best, _best_substring_coverage(cn, text) * 0.9)
        for en in explicit_names:
            rn = _clean_place_name(en)
            best = max(
                best,
                _name_overlap_score(cn, rn),
                _best_substring_coverage(cn, rn),
                _best_substring_coverage(rn, cn) * 0.92,
            )
    return min(1.0, best)


def _asset_name_bible(project: dict[str, Any]) -> str:
    """Force storyboard LLM to use library names for 出场/场景 lines."""
    chars = [
        str(a.get("name") or "").strip()
        for a in _asset_list(project, "characters")
        if isinstance(a, dict) and str(a.get("name") or "").strip()
    ]
    scenes = [
        str(a.get("name") or "").strip()
        for a in _asset_list(project, "scenes")
        if isinstance(a, dict) and str(a.get("name") or "").strip()
    ]
    if not chars and not scenes:
        return ""
    lines = [
        "【资产库标准名称——强制】",
        "每镜「出场：」「场景：」两行必须从下列名单选用标准名（可多选，用逗号分隔），",
        "禁止另造同义名/描写性地名（如把「小学教室」写成「破旧教室一角」）。",
    ]
    if chars:
        lines.append("人物名单：" + "、".join(chars[:24]))
    if scenes:
        lines.append("场景名单：" + "、".join(scenes[:24]))
    return "\n".join(lines)


def _rewrite_cast_line_names(prompt: str, project: dict[str, Any]) -> str:
    """Rewrite 场景/出场 lines to canonical asset names when fuzzy-matchable."""
    if not (prompt or "").strip():
        return prompt or ""

    def _repl(match: re.Match[str]) -> str:
        full = match.group(0)
        label = full
        body = match.group(1) or ""
        is_loc = any(k in label for k in _LOC_LABEL_MARKERS)
        kind = "scenes" if is_loc else "characters"
        parts = [n.strip() for n in NAME_SPLIT_RE.split(body) if n.strip()]
        mapped: list[str] = []
        for raw in parts:
            asset = find_asset(project, kind, raw, require_image=False, fuzzy=True)
            if asset is None:
                # soft overlap / substring pick（破旧教室 → 小学教室）
                best_a, best_s = None, 0.0
                for item in _asset_list(project, kind):
                    if not isinstance(item, dict):
                        continue
                    sc = 0.0
                    for n in _asset_names(item):
                        cn = _clean_place_name(n)
                        rn = _clean_place_name(raw)
                        sc = max(
                            sc,
                            _name_overlap_score(cn, rn),
                            _best_substring_coverage(cn, rn),
                            _best_substring_coverage(rn, cn) * 0.92,
                        )
                    if sc > best_s:
                        best_s, best_a = sc, item
                asset = best_a if best_s >= 0.34 else None
            if asset:
                canon = str(asset.get("name") or "").strip()
                if canon:
                    _learn_asset_alias(asset, raw)
                    if canon not in mapped:
                        mapped.append(canon)
                    continue
            cleaned = _clean_place_name(raw)
            if cleaned and cleaned not in mapped:
                mapped.append(cleaned)
        if not mapped:
            return full
        # Keep original label prefix (出场：/场景：)
        prefix = full[: full.index(body)] if body and body in full else (
            "场景：" if is_loc else "出场："
        )
        return prefix + "，".join(mapped)

    return CAST_LINE_RE.sub(_repl, prompt)

CHAPTER_STATUSES = (
    "pending",
    "storyboarded",
    "refs_ready",
    "generating",
    "done",
    "failed",
)


def novel_projects_root() -> Path:
    root = Path(folder_paths.get_output_directory()) / "minimax_novel_projects"
    root.mkdir(parents=True, exist_ok=True)
    return root


def stage_project_assets_to_input(project: dict[str, Any]) -> dict[str, Any]:
    """Ensure every character/scene image is staged under Comfy input for UI ``/view``."""
    pid = str(project.get("projectId") or "").strip()
    if not pid:
        return {"staged": 0, "assets": project.get("assets")}
    count = 0
    for kind in ("characters", "scenes"):
        for item in _asset_list(project, kind):
            if not isinstance(item, dict):
                continue
            src = ""
            abs_file = str(item.get("imageFile") or "").strip()
            rel = str(item.get("imagePath") or "").strip()
            if abs_file and Path(abs_file).is_file():
                src = abs_file
            elif rel:
                cand = project_dir(pid) / rel
                if cand.is_file():
                    src = str(cand)
                    item["imageFile"] = src
            if not src:
                continue
            staged = stage_image_to_input(pid, src, stem=str(item.get("name") or Path(src).stem))
            if staged and item.get("inputFile") != staged:
                item["inputFile"] = staged
                count += 1
            elif staged:
                item.setdefault("inputFile", staged)
    if count:
        save_project(project)
    return {"staged": count, "assets": project.get("assets")}


def resolve_project_asset_file(project_id: str, rel_path: str = "", input_file: str = "") -> Path | None:
    """Resolve a safe readable image path inside novel project or staged input."""
    pid = (project_id or "").strip()
    if input_file:
        rel = str(input_file).replace("\\", "/").lstrip("/")
        if ".." in rel.split("/"):
            return None
        cand = Path(folder_paths.get_input_directory()) / Path(rel)
        if cand.is_file():
            return cand
    if not pid:
        return None
    rel = str(rel_path or "").replace("\\", "/").lstrip("/")
    if not rel or ".." in rel.split("/"):
        return None
    root = project_dir(pid).resolve()
    cand = (root / Path(rel)).resolve()
    try:
        cand.relative_to(root)
    except Exception:
        return None
    return cand if cand.is_file() else None


def _is_absolute_fs_path(path: str) -> bool:
    norm = (path or "").replace("\\", "/")
    if not norm:
        return False
    if re.match(r"^[A-Za-z]:/", norm):
        return True
    return norm.startswith("/")


def stage_image_to_input(project_id: str, src: str | Path, *, stem: str = "") -> str:
    """Copy an asset image into Comfy ``input/minimax_novel/<projectId>/`` for UI preview + Queue.

    Returns input-relative path (forward slashes), or \"\" if source missing.
    """
    pid = (project_id or "").strip()
    path = Path(str(src or "").strip())
    if not pid or not path.is_file():
        return ""
    rel_dir = Path("minimax_novel") / pid
    dest_dir = Path(folder_paths.get_input_directory()) / rel_dir
    dest_dir.mkdir(parents=True, exist_ok=True)
    suffix = path.suffix or ".png"
    name = f"{_slug(stem or path.stem)}{suffix}"
    dest = dest_dir / name
    try:
        if (not dest.is_file()) or dest.stat().st_mtime < path.stat().st_mtime:
            dest.write_bytes(path.read_bytes())
    except OSError as exc:
        log.warning("stage novel image failed %s -> %s: %s", path, dest, exc)
        return ""
    return str((rel_dir / name).as_posix())


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())


def _slug(text: str, fallback: str = "item") -> str:
    raw = (text or "").strip()
    if not raw:
        return fallback
    safe = re.sub(r"[^\w\u4e00-\u9fff\-]+", "_", raw, flags=re.UNICODE).strip("_")
    if not safe:
        safe = hashlib.md5(raw.encode("utf-8")).hexdigest()[:10]
    return safe[:48]


def _read_json(path: Path, default: Any = None) -> Any:
    if not path.is_file():
        return default
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        log.warning("novel json read failed %s: %s", path, exc)
        return default


def _write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def default_novel_settings() -> dict[str, Any]:
    return {
        "maxShotsPerChapter": 8,
        "defaultDurationSec": 5.0,
        "autoConcatChapter": True,
        "reviewBeforeQueue": False,
        "shotMin": 2,
        "shotMax": 8,
        "durationMin": 2.0,
        "durationMax": 12.0,
    }


def default_novel_state() -> dict[str, Any]:
    return {
        "projectId": "",
        "title": "",
        "importMeta": {},
        "chapters": [],
        "currentChapterId": "",
        "history": [],
        "assets": {"characters": [], "scenes": []},
        "settings": default_novel_settings(),
        "updatedAt": "",
    }


def ensure_novel_state(timeline: dict | None) -> dict[str, Any]:
    tl = timeline if isinstance(timeline, dict) else {}
    novel = tl.get("novel")
    if not isinstance(novel, dict):
        novel = default_novel_state()
        tl["novel"] = novel
    novel.setdefault("projectId", "")
    novel.setdefault("title", "")
    novel.setdefault("importMeta", {})
    novel.setdefault("chapters", [])
    novel.setdefault("currentChapterId", "")
    novel.setdefault("history", [])
    assets = novel.get("assets")
    if not isinstance(assets, dict):
        assets = {"characters": [], "scenes": []}
        novel["assets"] = assets
    assets.setdefault("characters", [])
    assets.setdefault("scenes", [])
    settings = novel.get("settings")
    if not isinstance(settings, dict):
        settings = default_novel_settings()
        novel["settings"] = settings
    else:
        for k, v in default_novel_settings().items():
            settings.setdefault(k, v)
    return novel


def project_dir(project_id: str) -> Path:
    pid = (project_id or "").strip()
    if not pid or "/" in pid or "\\" in pid or ".." in pid:
        raise ValueError("无效的 projectId")
    return novel_projects_root() / pid


def load_project(project_id: str, *, stage_assets: bool = False) -> dict[str, Any]:
    path = project_dir(project_id) / "project.json"
    data = _read_json(path)
    if not isinstance(data, dict):
        raise FileNotFoundError(f"小说项目不存在: {project_id}")
    if stage_assets:
        try:
            stage_project_assets_to_input(data)
            data = _read_json(path) or data
        except Exception as exc:
            log.warning("stage assets on load failed: %s", exc)
    return data


def save_project(project: dict[str, Any]) -> dict[str, Any]:
    pid = str(project.get("projectId") or "").strip()
    if not pid:
        raise ValueError("projectId 为空")
    project["updatedAt"] = _now_iso()
    root = project_dir(pid)
    root.mkdir(parents=True, exist_ok=True)
    (root / "source").mkdir(exist_ok=True)
    (root / "assets" / "characters").mkdir(parents=True, exist_ok=True)
    (root / "assets" / "scenes").mkdir(parents=True, exist_ok=True)
    (root / "chapters").mkdir(exist_ok=True)
    _write_json(root / "project.json", project)
    _write_json(root / "assets" / "assets.json", project.get("assets") or {})
    return project


def list_projects() -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    root = novel_projects_root()
    for d in sorted(root.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True):
        if not d.is_dir():
            continue
        data = _read_json(d / "project.json")
        if not isinstance(data, dict):
            continue
        chapters = data.get("chapters") or []
        done = sum(1 for c in chapters if isinstance(c, dict) and c.get("status") == "done")
        out.append(
            {
                "projectId": data.get("projectId") or d.name,
                "title": data.get("title") or d.name,
                "updatedAt": data.get("updatedAt") or "",
                "chapterCount": len(chapters),
                "doneCount": done,
                "currentChapterId": data.get("currentChapterId") or "",
            }
        )
    return out


def delete_project(project_id: str) -> bool:
    import shutil

    root = project_dir(project_id)
    if not root.is_dir():
        return False
    shutil.rmtree(root, ignore_errors=True)
    return True


def _strip_html(text: str) -> str:
    text = re.sub(r"(?is)<script[^>]*>.*?</script>", "", text)
    text = re.sub(r"(?is)<style[^>]*>.*?</style>", "", text)
    text = re.sub(r"(?is)<br\s*/?>", "\n", text)
    text = re.sub(r"(?is)</p\s*>", "\n", text)
    text = re.sub(r"(?is)<[^>]+>", "", text)
    text = (
        text.replace("&nbsp;", " ")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&amp;", "&")
        .replace("&quot;", '"')
    )
    return text


def _normalize_novel_text(text: str) -> str:
    text = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    text = text.replace("\ufeff", "")
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def decode_import_payload(
    *,
    text: str = "",
    filename: str = "",
    file_b64: str = "",
) -> tuple[str, str]:
    """Return (plain_text, source_kind)."""
    name = (filename or "").strip().lower()
    raw_b64 = (file_b64 or "").strip()
    if raw_b64:
        if "," in raw_b64 and raw_b64.lower().startswith("data:"):
            raw_b64 = raw_b64.split(",", 1)[1]
        data = base64.b64decode(raw_b64)
        if name.endswith(".txt") or (not name and b"\x00" not in data[:200]):
            try:
                return _normalize_novel_text(data.decode("utf-8")), "txt"
            except UnicodeDecodeError:
                return _normalize_novel_text(data.decode("gb18030", errors="ignore")), "txt"
        if name.endswith(".epub") or data[:2] == b"PK":
            if name.endswith(".docx"):
                return _normalize_novel_text(_docx_to_text(data)), "docx"
            if name.endswith(".epub") or b"mimetype" in data[:200] or b"META-INF" in data[:4096]:
                # Ambiguous zip: prefer extension
                if name.endswith(".docx"):
                    return _normalize_novel_text(_docx_to_text(data)), "docx"
                if name.endswith(".epub"):
                    return _normalize_novel_text(_epub_to_text(data)), "epub"
            if name.endswith(".docx"):
                return _normalize_novel_text(_docx_to_text(data)), "docx"
            # sniff
            try:
                with zipfile.ZipFile(__import__("io").BytesIO(data)) as zf:
                    names = set(zf.namelist())
                    if "word/document.xml" in names:
                        return _normalize_novel_text(_docx_to_text(data)), "docx"
                    if "META-INF/container.xml" in names or "mimetype" in names:
                        return _normalize_novel_text(_epub_to_text(data)), "epub"
            except zipfile.BadZipFile:
                pass
            return _normalize_novel_text(data.decode("utf-8", errors="ignore")), "bin"
        if name.endswith(".docx"):
            return _normalize_novel_text(_docx_to_text(data)), "docx"
        if name.endswith(".epub"):
            return _normalize_novel_text(_epub_to_text(data)), "epub"
    pasted = _normalize_novel_text(text)
    if not pasted:
        raise ValueError("请粘贴小说文本或上传 txt/epub/docx 文件")
    return pasted, "paste"


def _docx_to_text(data: bytes) -> str:
    import io

    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        xml = zf.read("word/document.xml")
    root = ET.fromstring(xml)
    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    parts: list[str] = []
    for p in root.findall(".//w:p", ns):
        texts = [t.text or "" for t in p.findall(".//w:t", ns)]
        line = "".join(texts).strip()
        if line:
            parts.append(line)
    return "\n".join(parts)


def _epub_to_text(data: bytes) -> str:
    import io

    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        names = zf.namelist()
        # Prefer spine order via container → opf
        ordered: list[str] = []
        try:
            container = zf.read("META-INF/container.xml")
            croot = ET.fromstring(container)
            rootfile = None
            for el in croot.iter():
                if el.tag.endswith("rootfile"):
                    rootfile = el.attrib.get("full-path")
                    break
            if rootfile:
                opf = zf.read(rootfile)
                oroot = ET.fromstring(opf)
                id_to_href: dict[str, str] = {}
                for el in oroot.iter():
                    if el.tag.endswith("item"):
                        iid = el.attrib.get("id")
                        href = el.attrib.get("href")
                        if iid and href:
                            id_to_href[iid] = href
                manifest_dir = str(Path(rootfile).parent).replace("\\", "/")
                if manifest_dir == ".":
                    manifest_dir = ""
                for el in oroot.iter():
                    if el.tag.endswith("itemref"):
                        idref = el.attrib.get("idref")
                        href = id_to_href.get(idref or "")
                        if not href:
                            continue
                        full = f"{manifest_dir}/{href}".lstrip("/") if manifest_dir else href
                        ordered.append(full)
        except Exception as exc:
            log.warning("epub spine parse failed: %s", exc)
        if not ordered:
            ordered = [
                n
                for n in names
                if n.lower().endswith((".xhtml", ".html", ".htm")) and "meta-inf" not in n.lower()
            ]
        chunks: list[str] = []
        for name in ordered:
            try:
                raw = zf.read(name)
            except KeyError:
                continue
            try:
                html = raw.decode("utf-8")
            except UnicodeDecodeError:
                html = raw.decode("utf-8", errors="ignore")
            chunks.append(_strip_html(html))
        return "\n\n".join(chunks)


def split_chapters(text: str, *, title_hint: str = "") -> list[dict[str, Any]]:
    text = _normalize_novel_text(text)
    if not text:
        raise ValueError("小说正文为空")
    matches = list(CHAPTER_RE.finditer(text))
    chapters: list[dict[str, Any]] = []
    if matches:
        for i, m in enumerate(matches):
            start = m.start()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
            block = text[start:end].strip()
            title_line = m.group(0).strip()
            body = text[m.end() : end].strip()
            chapters.append(_make_chapter(i, title_line, body or block))
        return chapters

    # Fallback: blank-line blocks of decent size
    blocks = [b.strip() for b in re.split(r"\n\s*\n", text) if b.strip()]
    long_blocks = [b for b in blocks if len(b) >= 400]
    if len(long_blocks) >= 2:
        for i, b in enumerate(long_blocks):
            first = b.split("\n", 1)[0].strip()[:40]
            chapters.append(_make_chapter(i, first or f"第{i + 1}段", b))
        return chapters

    title = (title_hint or "全文").strip() or "全文"
    chapters.append(_make_chapter(0, title, text))
    return chapters


def _make_chapter(index: int, title: str, body: str) -> dict[str, Any]:
    cid = f"ch{index + 1:03d}_{uuid.uuid4().hex[:6]}"
    return {
        "id": cid,
        "index": index,
        "title": (title or f"第{index + 1}章").strip(),
        "text": body.strip(),
        "status": "pending",
        "shotCount": 0,
        "shots": [],
        "globalPrompt": "",
        "outputPath": "",
        "error": "",
        "updatedAt": _now_iso(),
    }


def import_novel(
    *,
    text: str = "",
    filename: str = "",
    file_b64: str = "",
    title: str = "",
    project_id: str = "",
) -> dict[str, Any]:
    plain, kind = decode_import_payload(text=text, filename=filename, file_b64=file_b64)
    stem = Path(filename).stem if filename else ""
    proj_title = (title or stem or "未命名小说").strip()[:120]
    pid = (project_id or "").strip() or f"novel_{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"
    chapters = split_chapters(plain, title_hint=proj_title)
    project = default_novel_state()
    project.update(
        {
            "projectId": pid,
            "title": proj_title,
            "importMeta": {
                "kind": kind,
                "filename": filename or "",
                "charCount": len(plain),
                "importedAt": _now_iso(),
            },
            "chapters": chapters,
            "currentChapterId": chapters[0]["id"] if chapters else "",
            "history": [
                {
                    "at": _now_iso(),
                    "action": "import",
                    "detail": f"{kind} · {len(chapters)} 章 · {len(plain)} 字",
                }
            ],
            "assets": {"characters": [], "scenes": []},
            "settings": default_novel_settings(),
        }
    )
    root = project_dir(pid)
    (root / "source").mkdir(parents=True, exist_ok=True)
    (root / "source" / "novel.txt").write_text(plain, encoding="utf-8")
    save_project(project)
    return project


def append_history(project: dict[str, Any], action: str, detail: str = "") -> None:
    hist = project.setdefault("history", [])
    if not isinstance(hist, list):
        hist = []
        project["history"] = hist
    hist.append({"at": _now_iso(), "action": action, "detail": detail or ""})
    if len(hist) > 200:
        del hist[:-200]


def get_chapter(project: dict[str, Any], chapter_id: str) -> dict[str, Any]:
    cid = (chapter_id or "").strip()
    for ch in project.get("chapters") or []:
        if isinstance(ch, dict) and ch.get("id") == cid:
            return ch
    raise KeyError(f"章节不存在: {chapter_id}")


def first_incomplete_chapter(project: dict[str, Any]) -> dict[str, Any] | None:
    for ch in project.get("chapters") or []:
        if isinstance(ch, dict) and ch.get("status") != "done":
            return ch
    return None


def _chapter_dir(project_id: str, chapter: dict[str, Any]) -> Path:
    idx = int(chapter.get("index") or 0) + 1
    d = project_dir(project_id) / "chapters" / f"{idx:03d}_{_slug(chapter.get('title') or chapter.get('id'))}"
    d.mkdir(parents=True, exist_ok=True)
    (d / "clips").mkdir(exist_ok=True)
    return d


def _safe_video_stem(title: str) -> str:
    """Filesystem-safe stem that keeps Chinese chapter titles readable."""
    s = (title or "").strip()
    s = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", s)
    s = re.sub(r"\s+", " ", s).strip(" .")
    return (s or "chapter")[:100]


def _resolve_comfy_media_path(
    *,
    source_path: str = "",
    filename: str = "",
    subfolder: str = "",
    file_type: str = "output",
) -> Path | None:
    if source_path:
        p = Path(str(source_path).strip())
        if p.is_file():
            return p.resolve()
    name = (filename or "").strip().replace("\\", "/")
    if not name:
        return None
    typ = (file_type or "output").strip().lower() or "output"
    try:
        base = Path(folder_paths.get_directory_by_type(typ) or folder_paths.get_output_directory())
    except Exception:
        base = Path(folder_paths.get_output_directory())
    sub = (subfolder or "").strip().replace("\\", "/").lstrip("/")
    cand = (base / sub / Path(name).name) if sub else (base / Path(name).name)
    if cand.is_file():
        return cand.resolve()
    # basename fallback under output root
    alt = base / Path(name).name
    if alt.is_file():
        return alt.resolve()
    return None


def find_newest_output_video(*, since_ts: float | None = None) -> Path | None:
    """Pick newest video under Comfy output/ (optionally only files modified after since_ts)."""
    try:
        root = Path(folder_paths.get_output_directory())
    except Exception:
        return None
    if not root.is_dir():
        return None
    best: Path | None = None
    best_mtime = -1.0
    exts = {".mp4", ".webm", ".mov", ".mkv"}
    try:
        for p in root.rglob("*"):
            if not p.is_file() or p.suffix.lower() not in exts:
                continue
            try:
                mtime = p.stat().st_mtime
            except OSError:
                continue
            if since_ts is not None and mtime + 0.05 < float(since_ts):
                continue
            if mtime >= best_mtime:
                best_mtime = mtime
                best = p
    except Exception as exc:
        log.warning("scan output videos failed: %s", exc)
        return None
    return best


def save_chapter_output_video(
    project_id: str,
    chapter_id: str,
    *,
    source_path: str = "",
    filename: str = "",
    subfolder: str = "",
    file_type: str = "output",
    since_ts: float | None = None,
    mark_done: bool = True,
) -> dict[str, Any]:
    """Copy a generated video into the chapter folder, named after the chapter title."""
    import shutil

    project = load_project(project_id)
    ch = get_chapter(project, chapter_id)
    src = _resolve_comfy_media_path(
        source_path=source_path,
        filename=filename,
        subfolder=subfolder,
        file_type=file_type,
    )
    if src is None:
        src = find_newest_output_video(since_ts=since_ts)
    if src is None or not src.is_file():
        raise FileNotFoundError(
            "未找到成片视频。请确认工作流末尾已接 CreateVideo→SaveVideo（或 Video Combine）并成功写出文件。"
        )

    cdir = _chapter_dir(project_id, ch)
    stem = _safe_video_stem(str(ch.get("title") or ch.get("id") or "chapter"))
    ext = src.suffix.lower() if src.suffix else ".mp4"
    if ext not in {".mp4", ".webm", ".mov", ".mkv", ".gif"}:
        ext = ".mp4"
    dest = cdir / f"{stem}{ext}"
    shutil.copy2(src, dest)
    rel = dest.relative_to(project_dir(project_id)).as_posix()
    if mark_done:
        result = update_chapter_progress(
            project_id,
            chapter_id,
            status="done",
            output_path=rel,
        )
        project = result["project"]
        ch = result["chapter"]
    else:
        ch["outputPath"] = rel
        ch["updatedAt"] = _now_iso()
        save_project(project)
    append_history(project, "save_video", f"{ch.get('title')} → {rel}")
    save_project(project)
    return {
        "chapter": ch,
        "project": project,
        "outputPath": rel,
        "absolutePath": str(dest),
        "sourcePath": str(src),
        "chapterDir": str(cdir),
    }


def _truncate_chapter_text(text: str, limit: int = 6000) -> str:
    text = (text or "").strip()
    if len(text) <= limit:
        return text
    return text[: limit - 20] + "\n…（后文已截断）"


def storyboard_chapter(
    project: dict[str, Any],
    chapter_id: str,
    *,
    model: str,
    backend: str = "local",
    continuity: str = "",
    desk_style: str = "",
    desk_soundscape: str = "",
    desk_music: str = "",
    skill_id: str | None = None,
    **llm_kwargs,
) -> dict[str, Any]:
    from .local_director_runtime import expand_story_auto
    from .skill_presets import resolve_novel_skill_id

    ch = get_chapter(project, chapter_id)
    settings = project.get("settings") or default_novel_settings()
    shot_max = max(1, min(16, int(settings.get("maxShotsPerChapter") or settings.get("shotMax") or 8)))
    shot_min = max(1, min(shot_max, int(settings.get("shotMin") or 2)))
    brief = _truncate_chapter_text(ch.get("text") or "")
    if not brief:
        raise ValueError("章节正文为空")

    sid = resolve_novel_skill_id(
        skill_id if skill_id is not None else llm_kwargs.pop("skill_id", None)
    )
    llm_kwargs.pop("skill_id", None)
    novel_sys_path = Path(__file__).resolve().parent.parent / "prompts" / "h3_novel_chapter_system.txt"
    novel_system = ""
    if novel_sys_path.is_file():
        novel_system = novel_sys_path.read_text(encoding="utf-8").strip()
    # Spatial / action emphasis + force library scene/character names
    bible = _asset_name_bible(project)
    brief_for_llm = (
        f"{brief}\n\n"
        "【小说短剧硬约束】分镜时加重人物站位与相对方位（左中右、前景中景远景、谁在谁身侧/对面），"
        "以及本镜主动作的起势→过程→落点；禁止只写抽象情节。"
        "对白必须用 <d>[中文] ……</d>，说话者写清角色名+（说n）+语气，且必须是本镜「出场」中的角色；"
        "口型与声线跟该角色一致，禁止错人配音；画外音须写明嘴唇完全闭合。"
        "每镜 duration 必须覆盖本镜全部对白自然说完所需时间（中文约 3～4 字/秒，含起落与停顿），"
        "勿把长对白塞进过短时长，也勿用空镜把短对白拖成冗长静默；动作节拍与对白起落同步。"
        "相邻镜必须承接：后镜开场站位/姿态续接前镜收束，禁止每镜重起幅；同场景背景连续，换场改「场景：」名。"
    )
    if bible:
        brief_for_llm = f"{brief_for_llm}\n\n{bible}"
    continuity_for_llm = continuity or ""
    if bible:
        continuity_for_llm = (continuity_for_llm + "\n\n" + bible).strip()

    result = expand_story_auto(
        model=model,
        brief=brief_for_llm,
        shot_min=shot_min,
        shot_max=shot_max,
        duration_min=float(settings.get("durationMin") or 2.0),
        duration_max=float(settings.get("durationMax") or 12.0),
        duration_hint=float(settings.get("defaultDurationSec") or 5.0),
        mode="REF2VA",
        continuity=continuity_for_llm,
        global_prompt="",
        desk_style=desk_style,
        desk_soundscape=desk_soundscape,
        desk_music=desk_music,
        backend=backend,
        skill_id=sid,
        system_prompt=novel_system or None,
        **llm_kwargs,
    )
    shots_raw = result.get("shots") or []
    shots: list[dict[str, Any]] = []
    for i, s in enumerate(shots_raw):
        if not isinstance(s, dict):
            continue
        prompt = str(s.get("prompt") or "").strip()
        if not prompt:
            continue
        # Normalize 出场/场景 lines to library canonical names + learn aliases
        prompt = _rewrite_cast_line_names(prompt, project)
        cast = _extract_cast_from_prompt(prompt, project.get("assets") or {})
        # expand_story_auto writes "duration"; older paths may use durationSec
        raw_dur = s.get("durationSec")
        if raw_dur is None:
            raw_dur = s.get("duration")
        dur = fit_novel_shot_duration(
            prompt,
            raw_dur,
            d_min=float(settings.get("durationMin") or 2.0),
            d_max=float(settings.get("durationMax") or 12.0),
            default=float(settings.get("defaultDurationSec") or 5.0),
        )
        shots.append(
            {
                "index": i,
                "label": str(s.get("label") or f"分镜{i + 1}"),
                "prompt": prompt,
                "durationSec": dur,
                "characters": cast["characters"],
                "locations": cast["locations"],
                "refs": [],
            }
        )
    if not shots:
        raise RuntimeError("章节分镜失败：未解析到有效分镜")

    ch["shots"] = shots
    ch["shotCount"] = len(shots)
    ch["globalPrompt"] = str(result.get("global_prompt") or result.get("globalPrompt") or "")
    ch["status"] = "storyboarded"
    ch["error"] = ""
    ch["updatedAt"] = _now_iso()
    project["currentChapterId"] = ch["id"]
    append_history(project, "storyboard", f"{ch.get('title')} · {len(shots)} 镜")
    cdir = _chapter_dir(str(project["projectId"]), ch)
    _write_json(cdir / "shots.json", {"globalPrompt": ch["globalPrompt"], "shots": shots})
    save_project(project)
    return {"chapter": ch, "shots": shots, "globalPrompt": ch["globalPrompt"]}


def _extract_cast_from_prompt(prompt: str, assets: dict[str, Any]) -> dict[str, list[str]]:
    chars: list[str] = []
    locs: list[str] = []
    text = prompt or ""
    for m in CAST_LINE_RE.finditer(text):
        label = m.group(0)
        names = [n.strip() for n in NAME_SPLIT_RE.split(m.group(1) or "") if n.strip()]
        # Strip trailing punctuation / decorative quotes
        names = [re.sub(r"^[\s「」『』\"'“”]+|[\s「」『』\"'“”。．.]+$", "", n) for n in names]
        names = [n for n in names if n]
        is_loc = any(k in label for k in _LOC_LABEL_MARKERS)
        target = locs if is_loc else chars
        for n in names:
            if n not in target:
                target.append(n)

    def _collect(kind: str, into: list[str]) -> None:
        hits: list[tuple[int, str]] = []
        for item in assets.get(kind) or []:
            if not isinstance(item, dict):
                continue
            canonical = str(item.get("name") or "").strip()
            aliases = [str(a).strip() for a in (item.get("aliases") or []) if str(a).strip()]
            for n in [canonical] + aliases:
                if len(n) < 2:
                    continue
                if n in text:
                    hits.append((len(n), canonical or n))
                    break
        # Longer names first to reduce short false positives
        hits.sort(key=lambda x: -x[0])
        for _, name in hits:
            if name and name not in into:
                into.append(name)

    _collect("characters", chars)
    _collect("scenes", locs)
    return {"characters": chars[:8], "locations": locs[:6]}


def _asset_list(project: dict[str, Any], kind: str) -> list[dict[str, Any]]:
    assets = project.setdefault("assets", {"characters": [], "scenes": []})
    key = "characters" if kind == "characters" else "scenes"
    lst = assets.setdefault(key, [])
    if not isinstance(lst, list):
        lst = []
        assets[key] = lst
    return lst


def _asset_has_image(asset: dict[str, Any] | None) -> bool:
    if not isinstance(asset, dict):
        return False
    return bool(
        str(asset.get("inputFile") or "").strip()
        or str(asset.get("imageFile") or "").strip()
        or str(asset.get("imagePath") or "").strip()
    )


def find_asset(
    project: dict[str, Any],
    kind: str,
    name: str,
    *,
    require_image: bool = False,
    fuzzy: bool = True,
) -> dict[str, Any] | None:
    """Exact name/alias match first; fuzzy uses Chinese overlap for 场景名漂移."""
    needle = _clean_place_name(name)
    if not needle:
        return None
    exact: list[dict[str, Any]] = []
    fuzzy_hits: list[tuple[float, dict[str, Any]]] = []
    for item in _asset_list(project, kind):
        if not isinstance(item, dict):
            continue
        names = _asset_names(item)
        matched = False
        for n in names:
            if n == needle or _clean_place_name(n) == needle:
                exact.append(item)
                matched = True
                break
        if matched or not fuzzy:
            continue
        best = 0.0
        for n in names:
            cn = _clean_place_name(n)
            best = max(best, _name_overlap_score(cn, needle))
            best = max(best, _best_substring_coverage(cn, needle))
            best = max(best, _best_substring_coverage(needle, cn) * 0.92)
            if cn in needle or needle in cn:
                best = max(best, 0.8)
        if best >= 0.34:
            fuzzy_hits.append((best, item))
    fuzzy_hits.sort(key=lambda x: -x[0])
    pool: list[dict[str, Any]] = []
    seen_ids: set[str] = set()
    for item in exact + [h[1] for h in fuzzy_hits]:
        iid = str(item.get("id") or id(item))
        if iid in seen_ids:
            continue
        seen_ids.add(iid)
        pool.append(item)
    if require_image:
        imaged = [i for i in pool if _asset_has_image(i)]
        if imaged:
            return imaged[0]
        return None
    return pool[0] if pool else None


def _merge_name_lists(*lists: Any) -> list[str]:
    out: list[str] = []
    for lst in lists:
        for n in _normalize_name_list(lst):
            cleaned = _clean_place_name(n) or n
            if cleaned and cleaned not in out:
                out.append(cleaned)
    return out


def _pick_assets_for_shot(
    project: dict[str, Any],
    kind: str,
    names: list[str],
    *,
    prompt: str = "",
    min_score: float = 0.42,
    max_n: int = 3,
) -> list[dict[str, Any]]:
    """Rank library assets for this shot; keep those above ``min_score``."""
    explicit = _merge_name_lists(names)
    scored: list[tuple[float, dict[str, Any]]] = []
    for item in _asset_list(project, kind):
        if not isinstance(item, dict) or not _asset_has_image(item):
            continue
        sc = _score_asset_for_shot(item, prompt=prompt, explicit_names=explicit)
        if sc >= min_score:
            scored.append((sc, item))
    scored.sort(key=lambda x: -x[0])
    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    for sc, asset in scored[: max(1, max_n)]:
        key = str(asset.get("id") or asset.get("name") or id(asset))
        if key in seen:
            continue
        seen.add(key)
        # Learn aliases from explicit names that matched this asset
        for en in explicit:
            if _name_overlap_score(str(asset.get("name") or ""), en) >= 0.42 or any(
                _name_overlap_score(a, en) >= 0.42 for a in _asset_names(asset)
            ):
                _learn_asset_alias(asset, en)
        out.append(asset)
    return out


def _resolve_assets_by_names(
    project: dict[str, Any],
    kind: str,
    names: list[str],
    *,
    prompt: str = "",
) -> list[dict[str, Any]]:
    """Map free-form names → library assets that have images (overlap-aware)."""
    max_n = 6 if kind == "characters" else 1
    min_score = 0.50 if kind == "scenes" else 0.50
    # Scenes: do NOT score against the whole multimodal body (causes 串台).
    # Characters may still use prompt body hits for appearance names.
    score_prompt = "" if kind == "scenes" else prompt
    return _pick_assets_for_shot(
        project,
        kind,
        names,
        prompt=score_prompt,
        min_score=min_score,
        max_n=max_n,
    )


def _extract_scene_line_names(prompt: str) -> list[str]:
    """Only names from explicit 场景/地点 lines (not body prose)."""
    names: list[str] = []
    for m in CAST_LINE_RE.finditer(prompt or ""):
        label = m.group(0)
        if not any(k in label for k in _LOC_LABEL_MARKERS):
            continue
        for n in NAME_SPLIT_RE.split(m.group(1) or ""):
            cleaned = _clean_place_name(n)
            if cleaned and cleaned not in names:
                names.append(cleaned)
    return names


def _resolve_scene_assets_for_shot(
    project: dict[str, Any],
    loc_names: list[str],
    prompt: str,
) -> list[dict[str, Any]]:
    """Pick at most one scene asset from explicit 场景： names — avoid whole-prompt guess."""
    explicit = _merge_name_lists(loc_names, _extract_scene_line_names(prompt))
    out: list[dict[str, Any]] = []
    seen: set[str] = set()

    def _add(asset: dict[str, Any] | None, alias: str = "") -> None:
        if not asset or not _asset_has_image(asset):
            return
        key = str(asset.get("id") or asset.get("name") or id(asset))
        if key in seen:
            return
        seen.add(key)
        if alias:
            _learn_asset_alias(asset, alias)
        out.append(asset)

    for name in explicit:
        _add(find_asset(project, "scenes", name, require_image=True, fuzzy=True), name)
        if out:
            break

    if out:
        return out[:1]

    # Soft match only against the joined 场景： names, never the full shot prose
    if explicit:
        joined = "，".join(explicit)
        soft = _pick_assets_for_shot(
            project,
            "scenes",
            explicit,
            prompt=joined,
            min_score=0.45,
            max_n=1,
        )
        return soft[:1]
    return []


def upsert_asset(
    project: dict[str, Any],
    *,
    kind: str,
    name: str,
    prompt: str = "",
    aliases: list[str] | None = None,
    image_path: str = "",
    image_b64: str = "",
) -> dict[str, Any]:
    kind_key = "characters" if kind in {"character", "characters", "char"} else "scenes"
    lst = _asset_list(project, kind_key)
    item = find_asset(project, kind_key, name)
    if item is None:
        item = {
            "id": f"{kind_key[:4]}_{uuid.uuid4().hex[:8]}",
            "name": (name or "").strip() or "未命名",
            "aliases": [],
            "prompt": "",
            "imageFile": "",
            "imagePath": "",
        }
        lst.append(item)
    if aliases:
        merged = list(item.get("aliases") or [])
        for a in aliases:
            a = str(a).strip()
            if a and a not in merged and a != item.get("name"):
                merged.append(a)
        item["aliases"] = merged[:12]
    if prompt:
        item["prompt"] = prompt.strip()
    rel_path = ""
    if image_b64:
        rel_path = _save_asset_image(project, kind_key, item, image_b64)
    elif image_path:
        src = Path(image_path)
        if src.is_file():
            rel_path = _copy_asset_image(project, kind_key, item, src)
    if rel_path:
        item["imagePath"] = rel_path
        abs_path = project_dir(str(project["projectId"])) / rel_path
        item["imageFile"] = str(abs_path)
        # Also stage into Comfy input so 分镜清单 / viewUrl 能预览
        staged = stage_image_to_input(
            str(project.get("projectId") or ""),
            abs_path,
            stem=str(item.get("name") or abs_path.stem),
        )
        if staged:
            item["inputFile"] = staged
    save_project(project)
    return item


def delete_asset(
    project: dict[str, Any],
    *,
    kind: str,
    asset_id: str = "",
    name: str = "",
    delete_files: bool = True,
) -> dict[str, Any]:
    """Remove a character/scene from the global asset library."""
    kind_key = "characters" if kind in {"character", "characters", "char"} else "scenes"
    lst = _asset_list(project, kind_key)
    aid = str(asset_id or "").strip()
    needle = str(name or "").strip()
    removed: dict[str, Any] | None = None
    keep: list[dict[str, Any]] = []
    for item in lst:
        if not isinstance(item, dict):
            continue
        hit = False
        if aid and str(item.get("id") or "") == aid:
            hit = True
        elif needle and (
            str(item.get("name") or "").strip() == needle
            or needle in [str(a).strip() for a in (item.get("aliases") or [])]
        ):
            hit = True
        if hit and removed is None:
            removed = item
            continue
        keep.append(item)
    if removed is None:
        raise KeyError(f"资产不存在: {aid or needle or '(空)'}")
    assets = project.setdefault("assets", {"characters": [], "scenes": []})
    assets[kind_key] = keep

    if delete_files:
        pid = str(project.get("projectId") or "")
        # Project-local image
        rel = str(removed.get("imagePath") or "").strip()
        if pid and rel:
            try:
                p = project_dir(pid) / rel
                if p.is_file():
                    p.unlink()
            except Exception as exc:
                log.warning("delete asset file failed %s: %s", rel, exc)
        abs_path = str(removed.get("imageFile") or "").strip()
        if abs_path:
            try:
                ap = Path(abs_path)
                if ap.is_file() and pid and str(project_dir(pid).resolve()) in str(ap.resolve()):
                    ap.unlink()
            except Exception:
                pass
        # Staged Comfy input copy
        inp = str(removed.get("inputFile") or "").strip().replace("\\", "/")
        if inp and not _is_absolute_fs_path(inp):
            try:
                cand = Path(folder_paths.get_input_directory()) / Path(inp)
                if cand.is_file():
                    cand.unlink()
            except Exception as exc:
                log.warning("delete staged input failed %s: %s", inp, exc)

    append_history(
        project,
        "delete_asset",
        f"删除{'人物' if kind_key == 'characters' else '场景'}：{removed.get('name') or aid or needle}",
    )
    save_project(project)
    return {"removed": removed, "kind": kind_key, "assets": project.get("assets")}


def _save_asset_image(project: dict[str, Any], kind_key: str, item: dict[str, Any], image_b64: str) -> str:
    raw = image_b64.strip()
    if "," in raw and raw.lower().startswith("data:"):
        raw = raw.split(",", 1)[1]
    data = base64.b64decode(raw)
    rel = f"assets/{kind_key}/{_slug(item.get('name') or item.get('id'))}.png"
    dest = project_dir(str(project["projectId"])) / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    return rel.replace("\\", "/")


def _copy_asset_image(project: dict[str, Any], kind_key: str, item: dict[str, Any], src: Path) -> str:
    rel = f"assets/{kind_key}/{_slug(item.get('name') or item.get('id'))}{src.suffix or '.png'}"
    dest = project_dir(str(project["projectId"])) / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(src.read_bytes())
    return rel.replace("\\", "/")


def merge_extracted_assets(project: dict[str, Any], extract_result: dict[str, Any]) -> dict[str, Any]:
    """Merge extract_assets / asset_prompts into persistent novel asset library (no image yet)."""
    prompts = extract_result.get("asset_prompts") or extract_result.get("assets") or {}
    chars = prompts.get("characters") if isinstance(prompts, dict) else None
    scenes = prompts.get("scenes") if isinstance(prompts, dict) else None
    # Also accept flat lists
    if chars is None:
        chars = extract_result.get("characters") or []
    if scenes is None:
        scenes = extract_result.get("scenes") or []
    added = {"characters": 0, "scenes": 0}
    for c in chars or []:
        if isinstance(c, str):
            name, prompt = c, ""
        elif isinstance(c, dict):
            name = str(c.get("name") or c.get("label") or "").strip()
            prompt = str(c.get("prompt") or c.get("image_prompt") or "").strip()
        else:
            continue
        if not name:
            continue
        existed = find_asset(project, "characters", name)
        upsert_asset(project, kind="characters", name=name, prompt=prompt)
        if existed is None:
            added["characters"] += 1
    for s in scenes or []:
        if isinstance(s, str):
            name, prompt = s, ""
        elif isinstance(s, dict):
            name = str(s.get("name") or s.get("label") or "").strip()
            prompt = str(s.get("prompt") or s.get("image_prompt") or "").strip()
        else:
            continue
        if not name:
            continue
        existed = find_asset(project, "scenes", name)
        upsert_asset(project, kind="scenes", name=name, prompt=prompt)
        if existed is None:
            added["scenes"] += 1
    append_history(
        project,
        "extract_assets",
        f"+人物{added['characters']} +场景{added['scenes']}",
    )
    save_project(project)
    return {"added": added, "assets": project.get("assets")}


def sync_assets_from_timeline(project: dict[str, Any], timeline: dict[str, Any]) -> dict[str, Any]:
    """Pull generated guide_refs / asset_prompts images into novel asset library."""
    idir = timeline.get("image_director") if isinstance(timeline, dict) else {}
    if not isinstance(idir, dict):
        idir = {}
    asset_prompts = idir.get("asset_prompts") or {}
    if isinstance(asset_prompts, dict):
        merge_extracted_assets(project, {"asset_prompts": asset_prompts})
    guide_refs = idir.get("guide_refs") or []
    synced = 0
    for ref in guide_refs:
        if not isinstance(ref, dict):
            continue
        role = str(ref.get("role") or "").lower()
        label = str(ref.get("label") or ref.get("name") or "").strip()
        image_file = str(ref.get("imageFile") or ref.get("file") or "").strip()
        if not label or not image_file:
            continue
        kind = "characters" if role in {"character", "char", "人物"} else "scenes"
        if role in {"scene", "location", "场景"}:
            kind = "scenes"
        path = Path(image_file)
        if not path.is_file():
            # try under input/output
            for base in (
                Path(folder_paths.get_input_directory()),
                Path(folder_paths.get_output_directory()),
            ):
                cand = base / image_file
                if cand.is_file():
                    path = cand
                    break
        if path.is_file():
            upsert_asset(project, kind=kind, name=label, image_path=str(path))
            synced += 1
    append_history(project, "sync_assets", f"同步参考图 {synced} 张")
    save_project(project)
    return {"synced": synced, "assets": project.get("assets")}


def _resolve_asset_input_path(project: dict[str, Any], asset: dict[str, Any]) -> str:
    """Return input-relative path for UI preview + Queue (never absolute FS paths)."""
    inp = str(asset.get("inputFile") or "").strip().replace("\\", "/")
    if inp and not _is_absolute_fs_path(inp):
        cand = Path(folder_paths.get_input_directory()) / Path(inp)
        if cand.is_file():
            return inp
    src = ""
    p = str(asset.get("imageFile") or "").strip()
    if p and Path(p).is_file():
        src = p
    else:
        rel = str(asset.get("imagePath") or "").strip()
        if rel:
            full = project_dir(str(project["projectId"])) / rel
            if full.is_file():
                src = str(full)
                asset["imageFile"] = src
    if not src:
        return inp if inp and not _is_absolute_fs_path(inp) else ""
    staged = stage_image_to_input(
        str(project.get("projectId") or ""),
        src,
        stem=str(asset.get("name") or Path(src).stem),
    )
    if staged:
        asset["inputFile"] = staged
        return staged
    return ""


def _normalize_name_list(names: Any) -> list[str]:
    out: list[str] = []
    if not isinstance(names, list):
        return out
    for n in names:
        s = str(n or "").strip()
        if s and s not in out:
            out.append(s)
    return out


def bind_chapter_refs(project: dict[str, Any], chapter_id: str) -> dict[str, Any]:
    """Attach only cast-matched character/scene images to each shot (dense Picture 1–N).

    Scene refs are reserved (not crowded out by characters). Names resolve with fuzzy
    match so「教室」can bind to asset「小学教室」.
    """
    ch = get_chapter(project, chapter_id)
    shots = ch.get("shots") or []
    if not shots:
        raise ValueError("请先完成本章分镜")
    # Ensure assets are staged so shot refs use Comfy input-relative paths (UI /view).
    stage_project_assets_to_input(project)
    has_any = any(
        _asset_has_image(a)
        for kind in ("characters", "scenes")
        for a in _asset_list(project, kind)
    )
    if not has_any:
        raise ValueError("全局参考图库为空：请先提取/上传人物与场景参考图")

    max_refs = 9
    bound_shots = 0
    bound_refs = 0
    bound_scene_refs = 0

    for shot in shots:
        if not isinstance(shot, dict):
            continue
        prompt = str(shot.get("prompt") or "")
        # Align 场景/出场 lines to library names before matching
        prompt = _rewrite_cast_line_names(prompt, project)
        cast = _extract_cast_from_prompt(prompt, project.get("assets") or {})
        # Merge storyboard cast + prompt lines + asset-name hits (do not let stale
        # unmatched names block library hits).
        char_names = _merge_name_lists(shot.get("characters"), cast.get("characters"))
        loc_names = _merge_name_lists(shot.get("locations"), cast.get("locations"))
        char_assets = _resolve_assets_by_names(
            project, "characters", char_names, prompt=prompt
        )
        # Scenes: only from「场景：」/locations — never fuzzy whole-prompt (prevents 串台)
        loc_assets = _resolve_scene_assets_for_shot(project, loc_names, prompt)

        shot["characters"] = [str(a.get("name") or "") for a in char_assets if a.get("name")]
        shot["locations"] = [str(a.get("name") or "") for a in loc_assets if a.get("name")]
        # Keep rewritten cast lines in stored prompt
        shot["prompt"] = prompt

        packed: list[dict[str, Any]] = []
        seen_paths: set[str] = set()

        def _push(asset: dict[str, Any] | None, role: str) -> bool:
            nonlocal packed
            if not asset or len(packed) >= max_refs:
                return False
            path = _resolve_asset_input_path(project, asset)
            if not path or path in seen_paths:
                return False
            seen_paths.add(path)
            name = str(asset.get("name") or "")
            idx = len(packed)
            packed.append(
                {
                    "index": idx,
                    "slot": idx,
                    "imageFile": path,
                    "label": name,
                    "role": role,
                    "roleLabel": name or ("人物" if role == "character" else "场景"),
                }
            )
            return True

        # One primary scene slot reserved; characters fill the rest
        scene_budget = min(1, len(loc_assets), max_refs)
        char_budget = min(len(char_assets), max_refs - scene_budget)
        for asset in char_assets[:char_budget]:
            _push(asset, "character")
        for asset in loc_assets[:scene_budget]:
            if _push(asset, "scene"):
                bound_scene_refs += 1

        shot["refs"] = packed
        # Stronger scene lock line in stored prompt for UI + generation
        prompt_locked = _ensure_picture_tags(prompt, packed)
        if loc_assets and packed:
            scene_ref = next((r for r in packed if r.get("role") == "scene"), None)
            if scene_ref is not None:
                pic_n = int(scene_ref.get("index", 0)) + 1
                lock = (
                    f"【场景锁定】本镜环境以 <Picture {pic_n}>（{scene_ref.get('label') or '场景'}）为准，"
                    "背景与空间不得漂到其它地点。"
                )
                if "【场景锁定】" not in prompt_locked:
                    prompt_locked = f"{lock}\n{prompt_locked}"
        shot["prompt"] = prompt_locked
        if packed:
            bound_shots += 1
            bound_refs += len(packed)

    ch["shots"] = shots
    ch["status"] = "refs_ready"
    ch["error"] = ""
    ch["updatedAt"] = _now_iso()
    append_history(
        project,
        "bind_refs",
        f"{ch.get('title')} · 按镜挂接 {bound_shots}/{len(shots)} 镜 · "
        f"{bound_refs} 张参考（含场景 {bound_scene_refs}）",
    )
    cdir = _chapter_dir(str(project["projectId"]), ch)
    _write_json(cdir / "shots.json", {"globalPrompt": ch.get("globalPrompt"), "shots": shots})
    save_project(project)
    return {
        "chapter": ch,
        "shotCount": len(shots),
        "boundShots": bound_shots,
        "boundRefs": bound_refs,
        "boundSceneRefs": bound_scene_refs,
    }


def _ensure_picture_tags(prompt: str, refs: list[dict[str, Any]]) -> str:
    prompt = (prompt or "").strip()
    # Drop stale 参考： prefix from a previous full-library bind
    lines = prompt.split("\n")
    if lines and lines[0].startswith("参考："):
        prompt = "\n".join(lines[1:]).strip()
    present = set(re.findall(r"<Picture\s+(\d+)\s*>", prompt, flags=re.I))
    tags: list[str] = []
    for ref in refs:
        if not isinstance(ref, dict) or not ref.get("imageFile"):
            continue
        try:
            i = int(ref.get("index", ref.get("slot")))
        except (TypeError, ValueError):
            continue
        if i < 0:
            continue
        n = str(i + 1)
        if n in present:
            continue
        label = str(ref.get("label") or "")
        role = str(ref.get("role") or "")
        hint = label or ("人物" if role == "character" else "场景" if role == "scene" else "")
        tags.append(f"<Picture {n}>（{hint}）" if hint else f"<Picture {n}>")
    if not tags:
        return prompt
    return ("参考：" + " ".join(tags) + "\n" + prompt).strip()


def prepare_chapter_timeline(
    project: dict[str, Any],
    chapter_id: str,
    timeline: dict | None = None,
) -> dict[str, Any]:
    """Build timeline segments/global refs for Queue (r2v/novel)."""
    stage_project_assets_to_input(project)
    ch = get_chapter(project, chapter_id)
    shots = ch.get("shots") or []
    if not shots:
        raise ValueError("请先完成本章分镜")
    # Always re-bind per-shot cast refs so library dump / stale absolute paths are healed
    try:
        bind_chapter_refs(project, chapter_id)
        ch = get_chapter(project, chapter_id)
        shots = ch.get("shots") or []
    except ValueError:
        # allow storyboard-only prepare without refs
        pass

    tl = dict(timeline) if isinstance(timeline, dict) else {}
    # Compact novel for timeline widget — full chapter text/shots stay on disk only.
    tl["novel"] = timeline_novel_patch(project)
    tl.setdefault("global", {})
    if isinstance(tl["global"], dict):
        tl["global"]["taskType"] = "novel"
        tl["global"]["prompt"] = ch.get("globalPrompt") or tl["global"].get("prompt") or ""
        # Novel: refs live on each shot — do not dump whole library into global strip
        tl["global"]["refs"] = []
    # Novel multi-shot: default 链式连贯 ON (was soft-only + often off → jump cuts).
    # Respect explicit user OFF (continuityEnabled=false).
    tl.setdefault("output", {})
    if isinstance(tl["output"], dict):
        out = tl["output"]
        if out.get("continuityEnabled") is False or out.get("continuity_enabled") is False:
            out["continuityEnabled"] = False
        else:
            out["continuityEnabled"] = True
        out.pop("continuity_enabled", None)
    segments: list[dict[str, Any]] = []
    pid = str(project.get("projectId") or "")
    settings = project.get("settings") or default_novel_settings()
    input_root = Path(folder_paths.get_input_directory()).resolve()

    def _to_input_rel(raw_path: str, label: str, slot: int) -> str:
        raw_path = (raw_path or "").strip()
        if not raw_path:
            return ""
        norm = raw_path.replace("\\", "/")
        # Already an input-relative path (e.g. minimax_novel/<pid>/foo.png)
        if not _is_absolute_fs_path(norm):
            cand = Path(folder_paths.get_input_directory()) / Path(norm)
            if cand.is_file():
                return norm
        src = Path(raw_path)
        if not src.is_file():
            # Never hand absolute FS paths to the frontend /view API
            return "" if _is_absolute_fs_path(norm) else norm
        try:
            rel = src.resolve().relative_to(input_root)
            return rel.as_posix()
        except Exception:
            pass
        return stage_image_to_input(pid, src, stem=label or f"slot{slot + 1}_{src.stem}")

    def _shot_ref_at(refs: list, i: int) -> dict[str, Any]:
        """Resolve shot ref for slot i (supports indexed or positional arrays)."""
        if not isinstance(refs, list):
            return {}
        for r in refs:
            if not isinstance(r, dict):
                continue
            idx = r.get("index", r.get("slot"))
            if idx is not None:
                try:
                    if int(idx) == i:
                        return r
                except (TypeError, ValueError):
                    pass
        if i < len(refs) and isinstance(refs[i], dict):
            # Positional fallback only when entries lack index/slot
            if refs[i].get("index") is None and refs[i].get("slot") is None:
                return refs[i]
        return {}

    for shot in shots:
        if not isinstance(shot, dict):
            continue
        refs = shot.get("refs") or []
        # Sparse indexed refs for 分镜清单 /view + Queue (must include index)
        norm_refs: list[dict[str, Any]] = []
        for i in range(9):
            r = _shot_ref_at(refs, i)
            raw_path = str(r.get("imageFile") or r.get("inputFile") or "").strip()
            if not raw_path:
                rel_hint = str(r.get("imagePath") or "").strip()
                if rel_hint:
                    cand = project_dir(pid) / rel_hint
                    if cand.is_file():
                        raw_path = str(cand)
            staged = _to_input_rel(raw_path, str(r.get("label") or ""), i)
            if not staged:
                continue
            role = str(r.get("role") or ("character" if i < 4 else "scene"))
            label = str(r.get("label") or "")
            entry = {
                "index": i,
                "slot": i,
                "imageFile": staged,
                "label": label,
                "role": role,
                "roleLabel": label or ("人物" if role == "character" else "场景" if role == "scene" else ""),
            }
            norm_refs.append(entry)
        prompt = str(shot.get("prompt") or "").strip()
        try:
            raw_dur = shot.get("durationSec")
            if raw_dur is None:
                raw_dur = shot.get("duration")
            dur = fit_novel_shot_duration(
                prompt,
                raw_dur,
                d_min=float(settings.get("durationMin") or 2.0),
                d_max=float(settings.get("durationMax") or 12.0),
                default=float(settings.get("defaultDurationSec") or 5.0),
            )
        except (TypeError, ValueError):
            dur = float(settings.get("defaultDurationSec") or 5.0)
        # Persist fitted duration back onto the shot for UI / re-export
        try:
            shot["durationSec"] = dur
        except Exception:
            pass
        segments.append(
            {
                "id": f"{ch['id']}_shot{int(shot.get('index') or 0) + 1}",
                "label": shot.get("label") or f"分镜{len(segments) + 1}",
                "prompt": prompt,
                "durationSec": dur,
                "runSelected": True,
                "run_selected": True,
                "refs": norm_refs,
                "refAudios": [],
                "refVideos": [],
                "taskType": "novel",
                "novelChapterId": ch["id"],
                "novelShotIndex": shot.get("index"),
                "characters": list(shot.get("characters") or []),
                "locations": list(shot.get("locations") or []),
            }
        )
    tl["segments"] = segments
    # guide_refs: unique assets actually used by this chapter's shots
    idir = tl.setdefault("image_director", {})
    if not isinstance(idir, dict):
        idir = {}
        tl["image_director"] = idir
    guide = []
    seen_guide: set[str] = set()
    for seg in segments:
        for r in seg.get("refs") or []:
            if not isinstance(r, dict):
                continue
            path = str(r.get("imageFile") or "")
            if not path or path in seen_guide:
                continue
            seen_guide.add(path)
            guide.append(
                {
                    "role": r.get("role") or "character",
                    "label": r.get("label") or path,
                    "imageFile": path,
                }
            )
    idir["guide_refs"] = guide

    ch["status"] = "generating"
    ch["error"] = ""
    ch["updatedAt"] = _now_iso()
    project["currentChapterId"] = ch["id"]
    append_history(project, "prepare", f"{ch.get('title')} · {len(segments)} 组分镜已装载")
    save_project(project)
    # Refresh compact novel AFTER status write so UI/timeline keep 生成中
    tl["novel"] = timeline_novel_patch(project)
    return {
        "timeline": tl,
        "chapter": chapter_summary(ch),
        "segmentCount": len(segments),
        "taskType": "novel",
        "novel": timeline_novel_patch(project),
    }


def update_chapter_progress(
    project_id: str,
    chapter_id: str,
    *,
    status: str,
    output_path: str = "",
    error: str = "",
) -> dict[str, Any]:
    project = load_project(project_id)
    ch = get_chapter(project, chapter_id)
    if status not in CHAPTER_STATUSES:
        raise ValueError(f"无效状态: {status}")
    ch["status"] = status
    if output_path:
        ch["outputPath"] = output_path
    ch["error"] = error or ""
    ch["updatedAt"] = _now_iso()
    if status == "done":
        nxt = first_incomplete_chapter(project)
        project["currentChapterId"] = nxt["id"] if nxt else ch["id"]
    else:
        project["currentChapterId"] = ch["id"]
    append_history(project, "progress", f"{ch.get('title')} → {status}")
    save_project(project)
    return {"project": project, "chapter": ch}


def chapter_summary(ch: dict[str, Any] | None) -> dict[str, Any]:
    """Lightweight chapter row for timeline UI (disk keeps full text/shots)."""
    if not isinstance(ch, dict):
        return {}
    shots = ch.get("shots") if isinstance(ch.get("shots"), list) else []
    shot_count = ch.get("shotCount")
    try:
        shot_count = int(shot_count) if shot_count is not None else len(shots)
    except (TypeError, ValueError):
        shot_count = len(shots)
    return {
        "id": ch.get("id") or "",
        "index": ch.get("index") if ch.get("index") is not None else 0,
        "title": ch.get("title") or "",
        "status": ch.get("status") or "pending",
        "shotCount": max(0, shot_count),
        "updatedAt": ch.get("updatedAt") or "",
        "outputPath": ch.get("outputPath") or "",
        "error": ch.get("error") or "",
    }


def _slim_asset(asset: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(asset, dict):
        return {}
    return {
        "id": asset.get("id") or "",
        "name": asset.get("name") or "",
        "aliases": list(asset.get("aliases") or []) if isinstance(asset.get("aliases"), list) else [],
        "imageFile": asset.get("imageFile") or "",
        "inputFile": asset.get("inputFile") or "",
        "imagePath": asset.get("imagePath") or "",
    }


def timeline_novel_patch(project: dict[str, Any]) -> dict[str, Any]:
    """Compact novel state for Comfy timeline widget (status/history survive reopen)."""
    chapters_raw = project.get("chapters") or []
    chapters = [chapter_summary(c) for c in chapters_raw if isinstance(c, dict)]
    hist = project.get("history") if isinstance(project.get("history"), list) else []
    assets = project.get("assets") if isinstance(project.get("assets"), dict) else {}
    return {
        "projectId": project.get("projectId") or "",
        "title": project.get("title") or "",
        "importMeta": project.get("importMeta") if isinstance(project.get("importMeta"), dict) else {},
        "chapters": chapters,
        "currentChapterId": project.get("currentChapterId") or "",
        "history": hist[-40:],
        "assets": {
            "characters": [
                _slim_asset(a) for a in (assets.get("characters") or []) if isinstance(a, dict)
            ],
            "scenes": [
                _slim_asset(a) for a in (assets.get("scenes") or []) if isinstance(a, dict)
            ],
        },
        "settings": project.get("settings") or default_novel_settings(),
        "updatedAt": project.get("updatedAt") or "",
    }


def mark_chapter_done_from_timeline(timeline: dict[str, Any], output_path: str = "") -> dict[str, Any] | None:
    novel = timeline.get("novel") if isinstance(timeline, dict) else None
    if not isinstance(novel, dict):
        return None
    pid = str(novel.get("projectId") or "").strip()
    cid = str(novel.get("currentChapterId") or "").strip()
    if not pid or not cid:
        return None
    try:
        return update_chapter_progress(pid, cid, status="done", output_path=output_path)
    except Exception as exc:
        log.warning("novel progress mark failed: %s", exc)
        return None
