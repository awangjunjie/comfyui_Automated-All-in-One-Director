/** Novel chapter mode UI: import → assets → storyboard → prepare → Queue. */

import { app } from "../../scripts/app.js";
import { api } from "../../scripts/api.js";
import { resolveTaskKey } from "./minimax_gen_timeline.js";
import {
    coerceIndexedRefs,
    ensureImageBatchTimeline,
    normalizeImageBatchSegments,
    renderImageBatchGroups,
} from "./minimax_image_batch.js";

const STATUS_LABEL = {
    pending: "待处理",
    storyboarded: "已分镜",
    refs_ready: "参考已挂",
    generating: "生成中",
    done: "已完成",
    failed: "失败",
};

const NOVEL_STYLES = `
.h3d-novel{display:flex;flex-direction:column;gap:10px;padding:10px 12px;border:1px solid rgba(255,255,255,.08);border-radius:10px;background:rgba(0,0,0,.22);margin-bottom:10px}
.h3d-novel[hidden]{display:none!important}
.h3d-novel-head{display:flex;align-items:center;justify-content:space-between;gap:8px}
.h3d-novel-head b{font-size:13px;letter-spacing:.02em}
.h3d-novel-head span{opacity:.7;font-size:11px}
.h3d-novel-hint{font-size:11px;opacity:.72;line-height:1.45;margin:0}
.h3d-novel-steps{display:flex;flex-wrap:wrap;gap:6px;align-items:center}
.h3d-novel-step{font-size:11px;padding:4px 8px;border-radius:6px;background:rgba(255,255,255,.05);opacity:.55;border:1px solid transparent}
.h3d-novel-step.done{opacity:.9;background:rgba(80,180,120,.18);border-color:rgba(80,180,120,.35)}
.h3d-novel-step.active{opacity:1;background:rgba(120,180,220,.2);border-color:rgba(120,180,220,.5);font-weight:600}
.h3d-novel-block{display:flex;flex-direction:column;gap:8px;padding:8px;border-radius:8px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06)}
.h3d-novel-block h4{margin:0;font-size:12px;opacity:.9}
.h3d-novel-block .h3d-novel-block-sub{font-size:10px;opacity:.55;margin:0}
.h3d-novel-row{display:flex;flex-wrap:wrap;gap:8px;align-items:center}
.h3d-novel textarea{width:100%;min-height:72px;resize:vertical;background:#141018;color:#eee;border:1px solid rgba(255,255,255,.12);border-radius:8px;padding:8px;font:12px/1.45 ui-sans-serif,system-ui}
.h3d-novel select,.h3d-novel input[type="text"]{background:#141018;color:#eee;border:1px solid rgba(255,255,255,.12);border-radius:6px;padding:4px 8px;font-size:12px}
.h3d-novel-chapters{display:flex;flex-direction:column;gap:4px;max-height:180px;overflow:auto}
.h3d-novel-history{display:flex;flex-direction:column;gap:3px;max-height:110px;overflow:auto;margin-top:6px;padding-top:6px;border-top:1px solid rgba(255,255,255,.06)}
.h3d-novel-history-item{font-size:10px;opacity:.72;line-height:1.35;display:grid;grid-template-columns:auto 1fr;gap:6px}
.h3d-novel-history-item b{font-weight:600;opacity:.9;white-space:nowrap}
.h3d-novel-ch{display:grid;grid-template-columns:1fr auto auto;gap:8px;align-items:center;padding:6px 8px;border-radius:6px;cursor:pointer;background:rgba(255,255,255,.03)}
.h3d-novel-ch:hover{background:rgba(255,255,255,.07)}
.h3d-novel-ch.active{outline:1px solid rgba(120,220,160,.55);background:rgba(60,120,90,.18)}
.h3d-novel-badge{font-size:10px;padding:2px 6px;border-radius:999px;background:rgba(255,255,255,.1)}
.h3d-novel-badge.done{background:rgba(80,180,120,.35)}
.h3d-novel-badge.generating{background:rgba(200,160,60,.35)}
.h3d-novel-badge.failed{background:rgba(200,80,80,.35)}
.h3d-novel-assets{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.h3d-novel-asset-col{display:flex;flex-direction:column;gap:6px;min-height:60px}
.h3d-novel-asset-col h4{margin:0;font-size:11px;opacity:.8}
.h3d-novel-asset{display:flex;gap:6px;align-items:center;font-size:11px}
.h3d-novel-asset img{width:36px;height:36px;object-fit:cover;border-radius:4px;background:#000}
.h3d-novel-asset-meta{flex:1;min-width:0}
.h3d-novel-asset-del{flex:none;font-size:11px;padding:2px 6px;line-height:1.2;opacity:.85}
.h3d-novel-asset-del:hover{opacity:1;color:#f0a0a0}
.h3d-novel-msg{font-size:11px;opacity:.8;min-height:1.2em;white-space:pre-wrap}
.h3d-novel-actions .h3d-btn{font-size:12px}
.h3d-novel-batch{display:flex;flex-wrap:wrap;gap:8px;align-items:center;padding:8px;border-radius:8px;background:rgba(120,180,220,.08);border:1px solid rgba(120,180,220,.25)}
.h3d-novel-batch label{font-size:11px;opacity:.9;display:inline-flex;align-items:center;gap:4px;user-select:none}
.h3d-novel-batch .h3d-btn[disabled]{opacity:.45;pointer-events:none}
`;

function ensureNovelStyles() {
    if (document.getElementById("h3d-novel-styles")) return;
    const style = document.createElement("style");
    style.id = "h3d-novel-styles";
    style.textContent = NOVEL_STYLES;
    document.head.appendChild(style);
}

export function isNovelTask(taskKey) {
    return resolveTaskKey(taskKey) === "novel";
}

export function defaultNovelState() {
    return {
        projectId: "",
        title: "",
        importMeta: {},
        chapters: [],
        currentChapterId: "",
        history: [],
        assets: { characters: [], scenes: [] },
        settings: {
            maxShotsPerChapter: 8,
            defaultDurationSec: 5,
            autoConcatChapter: true,
            reviewBeforeQueue: false,
            shotMin: 2,
            shotMax: 8,
            durationMin: 2,
            durationMax: 12,
        },
        updatedAt: "",
    };
}

export function ensureNovelTimeline(timeline) {
    if (!timeline || typeof timeline !== "object") return defaultNovelState();
    if (!timeline.novel || typeof timeline.novel !== "object") {
        timeline.novel = defaultNovelState();
    }
    timeline.novel = slimNovelForTimeline(timeline.novel);
    return timeline.novel;
}

/** Keep only chapter status rows in the Comfy widget — full text lives on disk. */
export function slimNovelForTimeline(novel) {
    const base = defaultNovelState();
    if (!novel || typeof novel !== "object") return base;
    const chapters = Array.isArray(novel.chapters) ? novel.chapters : [];
    const hist = Array.isArray(novel.history) ? novel.history : [];
    const assets = novel.assets && typeof novel.assets === "object" ? novel.assets : {};
    const slimAsset = (a) => ({
        id: a?.id || "",
        name: a?.name || "",
        aliases: Array.isArray(a?.aliases) ? a.aliases : [],
        imageFile: a?.imageFile || "",
        inputFile: a?.inputFile || "",
        imagePath: a?.imagePath || "",
    });
    return {
        ...base,
        ...novel,
        projectId: novel.projectId || "",
        title: novel.title || "",
        importMeta: novel.importMeta && typeof novel.importMeta === "object" ? novel.importMeta : {},
        currentChapterId: novel.currentChapterId || "",
        settings: { ...base.settings, ...(novel.settings || {}) },
        updatedAt: novel.updatedAt || "",
        chapters: chapters.map((ch) => ({
            id: ch?.id || "",
            index: ch?.index ?? 0,
            title: ch?.title || "",
            status: ch?.status || "pending",
            shotCount: Number(ch?.shotCount) || (Array.isArray(ch?.shots) ? ch.shots.length : 0) || 0,
            updatedAt: ch?.updatedAt || "",
            outputPath: ch?.outputPath || "",
            error: ch?.error || "",
        })),
        history: hist.slice(-40).map((h) => ({
            at: h?.at || h?.time || "",
            action: h?.action || "",
            detail: h?.detail || "",
        })),
        assets: {
            characters: (Array.isArray(assets.characters) ? assets.characters : []).map(slimAsset),
            scenes: (Array.isArray(assets.scenes) ? assets.scenes : []).map(slimAsset),
        },
    };
}

/** Reload chapter status / history from project.json (source of truth). */
export async function syncNovelFromDisk(editor, { silent = true } = {}) {
    const novel = ensureNovelTimeline(editor?.timeline);
    const pid = String(novel.projectId || "").trim();
    if (!pid) return null;
    try {
        const data = await novelApi("/minimax/director/novel/projects", {
            action: "load",
            projectId: pid,
        });
        const next = slimNovelForTimeline(data.novel || data.project);
        // Preserve local chapter selection if still valid
        const cur = novel.currentChapterId;
        if (cur && (next.chapters || []).some((c) => c.id === cur)) {
            next.currentChapterId = cur;
        }
        editor.timeline.novel = next;
        ensureNovelTimeline(editor.timeline);
        renderNovelPanel(editor);
        editor.commit?.(false, { syncTimeline: true });
        if (!silent) editor._novelSetMsg?.(`已同步项目状态：${next.title || pid}`);
        return next;
    } catch (err) {
        console.warn("[novel] sync from disk failed:", err);
        if (!silent) editor._novelSetMsg?.(String(err?.message || err), true);
        return null;
    }
}

async function novelApi(path, body) {
    const res = await api.fetchApi(path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body || {}),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok || data?.ok === false) {
        throw new Error(data?.error || `HTTP ${res.status}`);
    }
    return data;
}

function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}

function setNodeWidget(node, name, value) {
    const w = node?.widgets?.find((x) => x.name === name);
    if (!w) return false;
    w.value = value;
    w.callback?.(value);
    return true;
}

async function waitForComfyIdle(signal, { timeoutMs = 8 * 3600 * 1000 } = {}) {
    const t0 = Date.now();
    await sleep(900);
    while (Date.now() - t0 < timeoutMs) {
        if (signal?.aborted) throw new Error("已取消一键跑");
        let remaining = 0;
        try {
            const res = await api.fetchApi("/queue");
            const data = await res.json();
            remaining = (data?.queue_running?.length || 0) + (data?.queue_pending?.length || 0);
        } catch (_) {
            remaining = 1;
        }
        if (remaining === 0) {
            await sleep(1200);
            if (signal?.aborted) throw new Error("已取消一键跑");
            try {
                const res2 = await api.fetchApi("/queue");
                const data2 = await res2.json();
                const rem2 = (data2?.queue_running?.length || 0) + (data2?.queue_pending?.length || 0);
                if (rem2 === 0) return;
            } catch (_) {
                return;
            }
            continue;
        }
        await sleep(2000);
    }
    throw new Error("等待 Queue 超时");
}

function pickVideoFromHistoryEntry(entry) {
    const outs = entry?.outputs || {};
    for (const nodeOut of Object.values(outs)) {
        if (!nodeOut || typeof nodeOut !== "object") continue;
        for (const key of ["gifs", "videos", "images"]) {
            const arr = nodeOut[key];
            if (!Array.isArray(arr)) continue;
            for (const item of arr) {
                const fn = String(item?.filename || "");
                if (/\.(mp4|webm|mov|mkv)$/i.test(fn)) {
                    return {
                        filename: fn,
                        subfolder: item.subfolder || "",
                        type: item.type || "output",
                    };
                }
            }
        }
    }
    return null;
}

async function pickLatestHistoryVideo() {
    try {
        const res = await api.fetchApi("/history?max_items=12");
        const hist = await res.json();
        const entries = Object.entries(hist || {});
        // Prefer newest prompt ids (often appended); also try reverse insertion order
        for (let i = entries.length - 1; i >= 0; i -= 1) {
            const hit = pickVideoFromHistoryEntry(entries[i][1]);
            if (hit) return hit;
        }
    } catch (err) {
        console.warn("[novel] history scan failed:", err);
    }
    return null;
}

async function queueNovelChapterVideo(editor, signal) {
    const node = editor?.node;
    // Ensure full video path (not stills-only)
    setNodeWidget(node, "ref_gen_only", false);
    editor.commit?.(true, { syncTimeline: true });
    editor.flushTimelineSync?.();
    if (signal?.aborted) throw new Error("已取消一键跑");
    await app.queuePrompt(0);
    await waitForComfyIdle(signal);
}

function fileToB64(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ""));
        reader.onerror = reject;
        reader.readAsDataURL(file);
    });
}

function directorLlmPayload(editor) {
    const desk = editor?.timeline?.desk || {};
    const td = desk.text_director || {};
    const backend = String(td.backend || "local").toLowerCase() === "cloud" ? "cloud" : "local";
    const cloudModel = td.llm_model || td.llmModel || "";
    const localModel = td.model || editor.widget?.("local_director_model")?.value || "";
    const skillId = String(td.skill_id || "novel-short-drama").trim() || "novel-short-drama";
    return {
        model: backend === "cloud" ? (cloudModel || localModel) : (localModel || cloudModel),
        backend,
        llm_url: td.llm_url || td.llmUrl || "",
        api_format: td.llm_api_format || td.api_format || td.apiFormat || "Ollama",
        api_key: td.llm_api_key || td.api_key || td.apiKey || "",
        n_gpu_layers: td.n_gpu_layers ?? td.nGpuLayers,
        n_ctx: td.n_ctx ?? td.nCtx,
        temperature: td.temperature == null || td.temperature === "" ? 0.6 : td.temperature,
        mmproj: td.mmproj,
        thinking: td.zhipu_thinking ? "enabled" : "disabled",
        skill_id: skillId === "none" ? "novel-short-drama" : skillId,
        continuity: [
            desk.continuity?.characters,
            desk.continuity?.locations,
            desk.continuity?.props,
        ]
            .filter(Boolean)
            .join("\n"),
        deskStyle: desk.style || "",
        deskSoundscape: desk.soundscape || "",
        deskMusic: desk.music || "",
    };
}

export function mountNovelPanel(editor) {
    if (!editor?.root || editor._novelPanelMounted) return;
    editor._novelPanelMounted = true;
    ensureNovelStyles();
    ensureNovelTimeline(editor.timeline);

    const panel = document.createElement("div");
    panel.className = "h3d-novel";
    panel.dataset.r = "novel-panel";
    panel.hidden = true;
    panel.innerHTML = `
      <div class="h3d-novel-head">
        <b>小说章节 · 主流程</b>
        <span data-r="novel-progress">未导入</span>
      </div>
      <p class="h3d-novel-hint">分镜、挂图、装载请用本面板；下方工台「推理」仅配置 LLM / 风格声景。侧栏：导入 → 章节分镜 → 成片出库。</p>
      <div class="h3d-novel-steps" data-r="novel-steps">
        <span class="h3d-novel-step" data-step="1">1 导入</span>
        <span class="h3d-novel-step" data-step="2">2 资产</span>
        <span class="h3d-novel-step" data-step="3">3 分镜</span>
        <span class="h3d-novel-step" data-step="4">4 挂图</span>
        <span class="h3d-novel-step" data-step="5">5 装载</span>
      </div>

      <div class="h3d-novel-block" data-block="import">
        <h4>① 导入项目</h4>
        <p class="h3d-novel-block-sub">选择历史或导入 txt / epub / docx / 粘贴正文</p>
        <div class="h3d-novel-row">
          <select data-r="novel-history" title="历史项目" style="min-width:180px">
            <option value="">历史项目…</option>
          </select>
          <button type="button" class="h3d-btn" data-a="novel-refresh">刷新</button>
          <button type="button" class="h3d-btn" data-a="novel-continue">继续未完成章</button>
        </div>
        <div class="h3d-novel-row">
          <input type="text" data-r="novel-title" placeholder="小说标题（可选）" style="flex:1;min-width:140px" />
          <label class="h3d-btn" style="cursor:pointer">
            选择文件
            <input type="file" data-r="novel-file" accept=".txt,.epub,.docx,text/plain" hidden />
          </label>
          <button type="button" class="h3d-btn h3d-btn-primary" data-a="novel-import">一键导入</button>
        </div>
        <textarea data-r="novel-paste" placeholder="或在此粘贴全文 / 单章文本…"></textarea>
      </div>

      <div class="h3d-novel-block" data-block="assets">
        <h4>② 全局人物 / 场景参考库</h4>
        <p class="h3d-novel-block-sub">先提取名单，再上传定妆图（LLM 在下方「推理」页配置）</p>
        <div class="h3d-novel-row h3d-novel-actions">
          <button type="button" class="h3d-btn" data-a="novel-extract">提取全局资产</button>
        </div>
        <div class="h3d-novel-assets">
          <div class="h3d-novel-asset-col">
            <h4>人物参考库</h4>
            <div data-r="novel-chars"></div>
            <div class="h3d-novel-row">
              <input type="text" data-r="novel-char-name" placeholder="人物名" style="flex:1" />
              <label class="h3d-btn" style="cursor:pointer">上传图
                <input type="file" data-r="novel-char-file" accept="image/*" hidden />
              </label>
            </div>
          </div>
          <div class="h3d-novel-asset-col">
            <h4>场景参考库</h4>
            <div data-r="novel-scenes"></div>
            <div class="h3d-novel-row">
              <input type="text" data-r="novel-scene-name" placeholder="场景名" style="flex:1" />
              <label class="h3d-btn" style="cursor:pointer">上传图
                <input type="file" data-r="novel-scene-file" accept="image/*" hidden />
              </label>
            </div>
          </div>
        </div>
      </div>

      <div class="h3d-novel-block" data-block="chapter">
        <h4>③ 本章：分镜 → 挂图 → 装载</h4>
        <p class="h3d-novel-block-sub">点选下方章节后操作；装载后到侧栏「章节分镜」核对，再去「成片出库」Queue</p>
        <div class="h3d-novel-chapters" data-r="novel-chapters"></div>
        <div class="h3d-novel-history" data-r="novel-op-history" title="磁盘项目操作记录"></div>
        <div class="h3d-novel-row" data-r="novel-shot-range-row" title="本章自动分镜的镜数与单镜时长范围（写入项目设置）">
          <label style="font-size:11px;opacity:.85">镜数
            <input type="number" class="h3d-num" data-r="novel-shot-min" min="1" max="16" step="1" value="2" style="width:52px" title="镜数下限" />
            <span style="opacity:.6">～</span>
            <input type="number" class="h3d-num" data-r="novel-shot-max" min="1" max="16" step="1" value="8" style="width:52px" title="镜数上限（最多 16）" />
          </label>
          <label style="font-size:11px;opacity:.85">单镜秒数
            <input type="number" class="h3d-num" data-r="novel-dur-min" min="1" max="30" step="0.5" value="2" style="width:56px" title="单镜时长下限（秒）" />
            <span style="opacity:.6">～</span>
            <input type="number" class="h3d-num" data-r="novel-dur-max" min="1" max="30" step="0.5" value="12" style="width:56px" title="单镜时长上限（秒）" />
          </label>
        </div>
        <div class="h3d-novel-row h3d-novel-actions">
          <button type="button" class="h3d-btn" data-a="novel-storyboard">本章分镜</button>
          <button type="button" class="h3d-btn" data-a="novel-bind" title="仅按每镜出场人物/场景挂图，不会把整库塞进每一镜">按镜挂参考图</button>
          <button type="button" class="h3d-btn h3d-btn-primary" data-a="novel-prepare">装载并准备 Queue</button>
          <button type="button" class="h3d-btn" data-a="novel-mark-done">标记本章完成</button>
          <button type="button" class="h3d-btn" data-a="novel-sync" title="从磁盘项目重新读取章节状态与历史">同步状态</button>
        </div>
        <div class="h3d-novel-batch" data-r="novel-batch">
          <button type="button" class="h3d-btn h3d-btn-primary" data-a="novel-run-all"
            title="按当前镜数/时长设置，自动：分镜→挂图→装载→Queue→按章名保存视频">一键跑全书</button>
          <button type="button" class="h3d-btn" data-a="novel-run-cancel" hidden>停止一键跑</button>
          <label title="已完成章不再重跑"><input type="checkbox" data-r="novel-skip-done" checked />跳过已完成</label>
          <label title="本章已有分镜时不再调用 LLM 重拆"><input type="checkbox" data-r="novel-reuse-shots" checked />复用已有分镜</label>
        </div>
      </div>

      <div class="h3d-novel-msg" data-r="novel-msg"></div>
    `;

    // Prefer bible panel; fallback mainBody
    const bibleBody =
        editor.root.querySelector('[data-r="h3d-panel-body-bible"]') ||
        editor.root.querySelector(".h3d-main") ||
        editor.root;
    bibleBody.insertBefore(panel, bibleBody.firstChild);
    editor.novelPanel = panel;

    const q = (sel) => panel.querySelector(sel);
    const setMsg = (text, isErr = false) => {
        const el = q('[data-r="novel-msg"]');
        if (el) {
            el.textContent = text || "";
            el.style.color = isErr ? "#f0a0a0" : "";
        }
    };

    const applyNovel = (novel) => {
        if (!novel || typeof novel !== "object") return;
        editor.timeline.novel = slimNovelForTimeline(novel);
        ensureNovelTimeline(editor.timeline);
        renderNovelPanel(editor);
        editor.commit?.(false, { syncTimeline: true });
        editor.node?.setDirtyCanvas?.(true, true);
    };

    const readShotSettingsFromPanel = () => {
        const novel = ensureNovelTimeline(editor.timeline);
        const settings = { ...(novel.settings || {}) };
        let shotMin = parseInt(q('[data-r="novel-shot-min"]')?.value, 10);
        let shotMax = parseInt(q('[data-r="novel-shot-max"]')?.value, 10);
        let durMin = parseFloat(q('[data-r="novel-dur-min"]')?.value);
        let durMax = parseFloat(q('[data-r="novel-dur-max"]')?.value);
        if (!Number.isFinite(shotMin) || shotMin < 1) shotMin = 2;
        if (!Number.isFinite(shotMax) || shotMax < 1) shotMax = 8;
        shotMax = Math.max(1, Math.min(16, shotMax));
        shotMin = Math.max(1, Math.min(shotMax, shotMin));
        if (!Number.isFinite(durMin) || durMin < 0.5) durMin = 2;
        if (!Number.isFinite(durMax) || durMax < 0.5) durMax = 12;
        durMax = Math.max(1, Math.min(30, durMax));
        durMin = Math.max(0.5, Math.min(durMax, durMin));
        settings.shotMin = shotMin;
        settings.shotMax = shotMax;
        settings.maxShotsPerChapter = shotMax;
        settings.durationMin = durMin;
        settings.durationMax = durMax;
        novel.settings = settings;
        // Keep inputs normalized
        const minEl = q('[data-r="novel-shot-min"]');
        const maxEl = q('[data-r="novel-shot-max"]');
        const dMinEl = q('[data-r="novel-dur-min"]');
        const dMaxEl = q('[data-r="novel-dur-max"]');
        if (minEl) minEl.value = String(shotMin);
        if (maxEl) maxEl.value = String(shotMax);
        if (dMinEl) dMinEl.value = String(durMin);
        if (dMaxEl) dMaxEl.value = String(durMax);
        return settings;
    };

    for (const sel of [
        '[data-r="novel-shot-min"]',
        '[data-r="novel-shot-max"]',
        '[data-r="novel-dur-min"]',
        '[data-r="novel-dur-max"]',
    ]) {
        q(sel)?.addEventListener("change", () => {
            readShotSettingsFromPanel();
            editor.commit?.(false, { syncTimeline: true });
        });
    }

    const selectedChapterId = () =>
        editor.timeline?.novel?.currentChapterId ||
        editor.timeline?.novel?.chapters?.[0]?.id ||
        "";

    const setBatchRunningUi = (running) => {
        const runBtn = q('[data-a="novel-run-all"]');
        const cancelBtn = q('[data-a="novel-run-cancel"]');
        if (runBtn) runBtn.disabled = !!running;
        if (cancelBtn) cancelBtn.hidden = !running;
        for (const sel of [
            '[data-a="novel-storyboard"]',
            '[data-a="novel-bind"]',
            '[data-a="novel-prepare"]',
            '[data-a="novel-mark-done"]',
        ]) {
            const el = q(sel);
            if (el) el.disabled = !!running;
        }
    };

    const applyPreparedTimeline = (data) => {
        const prepared = data.timeline || {};
        const preparedSegs = Array.isArray(prepared.segments)
            ? JSON.parse(JSON.stringify(prepared.segments))
            : [];
        const tw = editor.taskTypeWidget || editor.widget?.("task_type");
        if (tw) {
            const opts = tw.options?.values || [];
            const hit = opts.find((o) => String(o).startsWith("novel"));
            if (hit) tw.value = hit;
            else tw.value = "novel — 小说章节(Novel Chapters)";
        }
        if (editor.globalTask) {
            const opts = [...(editor.globalTask.options || [])].map((o) => o.value || o);
            const hit = opts.find((o) => String(o).startsWith("novel"));
            if (hit) editor.globalTask.value = hit;
        }
        editor.applyTaskLayout?.();
        if (prepared.novel) editor.timeline.novel = slimNovelForTimeline(prepared.novel);
        else if (data.novel) applyNovel(data.novel);
        else applyNovel(editor.timeline.novel);
        if (prepared.image_director) {
            editor.timeline.image_director = prepared.image_director;
        }
        for (const seg of preparedSegs) {
            if (seg) seg.refs = coerceIndexedRefs(seg.refs);
        }
        if (prepared.global && typeof prepared.global === "object") {
            const gRefs = coerceIndexedRefs(prepared.global.refs);
            editor.timeline.global = {
                ...(editor.timeline.global || {}),
                ...prepared.global,
                taskType: "novel",
                refs: gRefs,
            };
        }
        editor.timeline.segments = preparedSegs;
        editor.timeline.editMode = "segment";
        editor.timeline.timelineMode = "prompt_batch";
        editor._batchWorkspaceStash = null;
        try {
            if (editor.timeline.global) editor.timeline.global.refs = [];
            ensureImageBatchTimeline(editor);
            normalizeImageBatchSegments(editor);
            renderImageBatchGroups(editor);
            editor.updateContinuityUI?.();
            editor.updateSeamDedupeUI?.();
        } catch (err) {
            console.warn("[novel] refresh batch cards failed:", err);
        }
        updateNovelPanelVisibility(editor);
        editor.syncBinderContent?.();
        editor.commit?.(true, { syncTimeline: true });
        editor.updateDomWidgetHeight?.();
        editor.node?.setDirtyCanvas?.(true, true);
        return preparedSegs;
    };

    const prepareChapterOntoTimeline = async (chapterId) => {
        const novel = ensureNovelTimeline(editor.timeline);
        const data = await novelApi("/minimax/director/novel/chapter/prepare", {
            projectId: novel.projectId,
            chapterId,
            timeline: editor.timeline,
        });
        const segs = applyPreparedTimeline(data);
        return { data, segs };
    };

    const runOneChapterPipeline = async (chapter, settings, llm, opts, signal) => {
        const novel = ensureNovelTimeline(editor.timeline);
        const pid = novel.projectId;
        const cid = chapter.id;
        const title = chapter.title || cid;
        const reuseShots = !!opts.reuseShots;
        const hasShots = Number(chapter.shotCount || 0) > 0
            || (Array.isArray(chapter.shots) && chapter.shots.length > 0)
            || ["storyboarded", "refs_ready", "generating"].includes(String(chapter.status || ""));

        novel.currentChapterId = cid;
        editor.commit?.(false, { syncTimeline: true });
        renderNovelPanel(editor);

        if (!(reuseShots && hasShots)) {
            setMsg(`【${title}】分镜中…（镜数 ${settings.shotMin}～${settings.shotMax}）`);
            const sb = await novelApi("/minimax/director/novel/chapter/storyboard", {
                projectId: pid,
                chapterId: cid,
                settings,
                ...llm,
            });
            applyNovel(sb.novel || sb.project);
            if (signal?.aborted) throw new Error("已取消一键跑");
        } else {
            setMsg(`【${title}】复用已有分镜…`);
        }

        setMsg(`【${title}】挂参考图…`);
        const bound = await novelApi("/minimax/director/novel/assets/bind", {
            projectId: pid,
            chapterId: cid,
        });
        applyNovel(bound.novel || bound.project);
        if (signal?.aborted) throw new Error("已取消一键跑");

        setMsg(`【${title}】装载时间线…`);
        await prepareChapterOntoTimeline(cid);
        if (signal?.aborted) throw new Error("已取消一键跑");

        const sinceTs = Date.now() / 1000 - 1;
        setMsg(`【${title}】Queue 生成中…请保持本页打开`);
        editor.showBinderStep?.("output");
        await queueNovelChapterVideo(editor, signal);

        setMsg(`【${title}】保存成片到章节文件夹…`);
        const media = await pickLatestHistoryVideo();
        const saved = await novelApi("/minimax/director/novel/chapter/save_output", {
            projectId: pid,
            chapterId: cid,
            sinceTs,
            markDone: true,
            ...(media || {}),
        });
        applyNovel(saved.novel || saved.project);
        return saved;
    };

    const runAllChapters = async () => {
        if (editor._novelBatchRunning) return;
        const novel = ensureNovelTimeline(editor.timeline);
        if (!novel.projectId) throw new Error("请先导入或打开小说项目");
        const settings = readShotSettingsFromPanel();
        const llm = directorLlmPayload(editor);
        if (!llm.model) throw new Error("请先在「推理」页配置提示词导演模型");
        const skipDone = !!q('[data-r="novel-skip-done"]')?.checked;
        const reuseShots = !!q('[data-r="novel-reuse-shots"]')?.checked;
        const chapters = [...(novel.chapters || [])].filter((c) => c && c.id);
        if (!chapters.length) throw new Error("项目没有章节");

        const queue = chapters.filter((c) => !(skipDone && c.status === "done"));
        if (!queue.length) {
            setMsg("没有需要跑的章节（均已完成）");
            return;
        }

        const abort = new AbortController();
        editor._novelBatchAbort = abort;
        editor._novelBatchRunning = true;
        setBatchRunningUi(true);
        const okTitles = [];
        const failTitles = [];
        try {
            setMsg(
                `一键跑启动：共 ${queue.length} 章，沿用镜数 ${settings.shotMin}～${settings.shotMax}、`
                + `单镜 ${settings.durationMin}～${settings.durationMax}s`,
            );
            for (let i = 0; i < queue.length; i += 1) {
                if (abort.signal.aborted) throw new Error("已取消一键跑");
                const ch = queue[i];
                const title = ch.title || ch.id;
                setMsg(`一键跑 ${i + 1}/${queue.length}：${title}`);
                try {
                    const saved = await runOneChapterPipeline(
                        ch,
                        settings,
                        llm,
                        { reuseShots },
                        abort.signal,
                    );
                    okTitles.push(`${title} → ${saved.outputPath || "已保存"}`);
                } catch (err) {
                    if (abort.signal.aborted || /已取消/.test(String(err?.message || err))) {
                        throw err;
                    }
                    console.error(err);
                    failTitles.push(`${title}: ${err?.message || err}`);
                    try {
                        await novelApi("/minimax/director/novel/progress", {
                            projectId: novel.projectId,
                            chapterId: ch.id,
                            status: "failed",
                            error: String(err?.message || err),
                        });
                        await syncNovelFromDisk(editor, { silent: true });
                    } catch (_) { /* ignore */ }
                }
            }
            const lines = [
                `一键跑结束：成功 ${okTitles.length}，失败 ${failTitles.length}`,
                ...okTitles.map((s) => `✓ ${s}`),
                ...failTitles.map((s) => `✗ ${s}`),
            ];
            setMsg(lines.join("\n"), failTitles.length > 0);
        } finally {
            editor._novelBatchRunning = false;
            editor._novelBatchAbort = null;
            setBatchRunningUi(false);
            await syncNovelFromDisk(editor, { silent: true });
            renderNovelPanel(editor);
        }
    };

    editor._novelSetMsg = setMsg;

    panel.addEventListener("click", async (ev) => {
        const btn = ev.target?.closest?.("[data-a]");
        if (!btn || !panel.contains(btn)) return;
        const action = btn.dataset.a;
        try {
            if (action === "novel-run-cancel") {
                editor._novelBatchAbort?.abort?.();
                setMsg("正在停止一键跑（当前章生成结束后生效）…");
                return;
            }
            if (action === "novel-run-all") {
                await runAllChapters();
                return;
            }
            if (action === "novel-refresh") {
                await refreshNovelHistory(editor);
                await syncNovelFromDisk(editor, { silent: false });
                setMsg("已刷新历史项目与章节状态");
                return;
            }
            if (action === "novel-sync") {
                setMsg("正在从磁盘同步章节状态…");
                await syncNovelFromDisk(editor, { silent: false });
                return;
            }
            if (action === "novel-import") {
                setMsg("正在导入…");
                const file = q('[data-r="novel-file"]')?.files?.[0];
                const payload = {
                    title: q('[data-r="novel-title"]')?.value || "",
                    text: q('[data-r="novel-paste"]')?.value || "",
                };
                if (file) {
                    payload.filename = file.name;
                    payload.fileB64 = await fileToB64(file);
                }
                const data = await novelApi("/minimax/director/novel/import", payload);
                applyNovel(data.novel || data.project);
                await refreshNovelHistory(editor);
                setMsg(`导入成功：${(data.project?.chapters || []).length} 章`);
                return;
            }
            if (action === "novel-continue") {
                const novel = ensureNovelTimeline(editor.timeline);
                const next = (novel.chapters || []).find((c) => c.status !== "done");
                if (!next) {
                    setMsg("全部章节已完成", false);
                    return;
                }
                novel.currentChapterId = next.id;
                applyNovel(novel);
                setMsg(`已定位：${next.title}`);
                return;
            }
            const novel = ensureNovelTimeline(editor.timeline);
            if (!novel.projectId) throw new Error("请先导入或打开小说项目");
            const llm = directorLlmPayload(editor);
            if (action === "novel-extract") {
                setMsg("正在提取全局人物/场景…");
                const data = await novelApi("/minimax/director/novel/assets/extract", {
                    projectId: novel.projectId,
                    timeline: editor.timeline,
                    enableGen: false,
                    ...llm,
                });
                if (data.timeline) Object.assign(editor.timeline, data.timeline);
                applyNovel(data.novel || data.project);
                setMsg("全局资产已写入参考库（可再上传定妆图）");
                return;
            }
            if (action === "novel-storyboard") {
                setMsg("本章分镜中…");
                const settings = readShotSettingsFromPanel();
                const data = await novelApi("/minimax/director/novel/chapter/storyboard", {
                    projectId: novel.projectId,
                    chapterId: selectedChapterId(),
                    settings,
                    ...llm,
                });
                applyNovel(data.novel || data.project);
                setMsg(
                    `分镜完成：${data.shotCount || data.shots?.length || 0} 镜`
                    + `（范围 ${settings.shotMin}～${settings.shotMax}）`,
                );
                return;
            }
            if (action === "novel-bind") {
                setMsg("按镜匹配出场人物/场景…");
                const data = await novelApi("/minimax/director/novel/assets/bind", {
                    projectId: novel.projectId,
                    chapterId: selectedChapterId(),
                });
                applyNovel(data.novel || data.project);
                setMsg(
                    `已按镜挂接：${data.boundShots || 0}/${data.shotCount || 0} 镜，`
                    + `共 ${data.boundRefs || 0} 张参考（场景 ${data.boundSceneRefs || 0}）`,
                );
                return;
            }
            if (action === "novel-prepare") {
                setMsg("装载章节到时间线…");
                const { data, segs } = await prepareChapterOntoTimeline(selectedChapterId());
                editor.showBinderStep?.("shots");
                const n = segs.length || data.segmentCount || 0;
                const withPrompt = segs.filter((s) => String(s?.prompt || "").trim()).length;
                const withRef = segs.filter(
                    (s) => Array.isArray(s?.refs) && s.refs.some((r) => r?.imageFile)
                ).length;
                setMsg(
                    `已装载 ${n} 组分镜（含提示词 ${withPrompt}，含参考图 ${withRef}）。`
                    + `请到侧栏「章节分镜」核对后，再去「成片出库」Queue`,
                );
                return;
            }
            if (action === "novel-mark-done") {
                const data = await novelApi("/minimax/director/novel/progress", {
                    projectId: novel.projectId,
                    chapterId: selectedChapterId(),
                    status: "done",
                });
                applyNovel(data.novel || data.project);
                setMsg("已标记本章完成");
            }
        } catch (err) {
            console.error(err);
            setMsg(String(err?.message || err), true);
        }
    });

    q('[data-r="novel-history"]')?.addEventListener("change", async (ev) => {
        const id = ev.target.value;
        if (!id) return;
        try {
            const data = await novelApi("/minimax/director/novel/projects", {
                action: "load",
                projectId: id,
            });
            applyNovel(data.novel || data.project);
            setMsg(`已打开：${data.project?.title || id}`);
        } catch (err) {
            setMsg(String(err?.message || err), true);
        }
    });

    const uploadAsset = async (kind, nameSel, fileSel) => {
        const name = q(nameSel)?.value?.trim();
        const file = q(fileSel)?.files?.[0];
        const novel = ensureNovelTimeline(editor.timeline);
        if (!novel.projectId) throw new Error("请先导入项目");
        if (!name) throw new Error("请填写名称");
        if (!file) throw new Error("请选择图片");
        setMsg(`上传${kind === "characters" ? "人物" : "场景"}图…`);
        const data = await novelApi("/minimax/director/novel/assets/upload", {
            projectId: novel.projectId,
            kind,
            name,
            imageB64: await fileToB64(file),
        });
        applyNovel(data.novel || data.project);
        setMsg("参考图已保存到全局库");
        if (q(fileSel)) q(fileSel).value = "";
    };

    q('[data-r="novel-char-file"]')?.addEventListener("change", async () => {
        try {
            await uploadAsset("characters", '[data-r="novel-char-name"]', '[data-r="novel-char-file"]');
        } catch (err) {
            setMsg(String(err?.message || err), true);
        }
    });
    q('[data-r="novel-scene-file"]')?.addEventListener("change", async () => {
        try {
            await uploadAsset("scenes", '[data-r="novel-scene-name"]', '[data-r="novel-scene-file"]');
        } catch (err) {
            setMsg(String(err?.message || err), true);
        }
    });

    editor._novelSetMsg = setMsg;
    refreshNovelHistory(editor).catch(() => {});
    // Reopen / reload: pull chapter status from disk project.json
    syncNovelFromDisk(editor, { silent: true }).finally(() => renderNovelPanel(editor));
}

export async function refreshNovelHistory(editor) {
    const panel = editor?.novelPanel;
    if (!panel) return;
    const sel = panel.querySelector('[data-r="novel-history"]');
    if (!sel) return;
    try {
        const res = await api.fetchApi("/minimax/director/novel/projects");
        const data = await res.json();
        const projects = data.projects || [];
        const cur = editor.timeline?.novel?.projectId || "";
        sel.innerHTML = `<option value="">历史项目…</option>`;
        for (const p of projects) {
            const opt = document.createElement("option");
            opt.value = p.projectId;
            opt.textContent = `${p.title}（${p.doneCount}/${p.chapterCount}）`;
            if (p.projectId === cur) opt.selected = true;
            sel.appendChild(opt);
        }
    } catch {
        /* ignore */
    }
}

function comfyInputViewUrl(imageFile) {
    const norm = String(imageFile || "").replace(/\\/g, "/");
    if (!norm || /^[A-Za-z]:\//.test(norm) || norm.startsWith("/")) return "";
    const slash = norm.lastIndexOf("/");
    const filename = slash >= 0 ? norm.slice(slash + 1) : norm;
    const subfolder = slash >= 0 ? norm.slice(0, slash) : "";
    const params = new URLSearchParams({ filename, type: "input" });
    if (subfolder) params.set("subfolder", subfolder);
    return api.apiURL(`/view?${params.toString()}`);
}

function assetThumbUrl(projectId, asset) {
    const a = asset || {};
    if (String(a.imageB64 || "").startsWith("data:")) return a.imageB64;
    const viaInput = comfyInputViewUrl(a.inputFile || "");
    if (viaInput) return viaInput;
    // Fallback: project-local file served by novel image route
    const rel = String(a.imagePath || "").replace(/\\/g, "/");
    const inp = String(a.inputFile || "").replace(/\\/g, "/");
    if (projectId && (rel || inp)) {
        const params = new URLSearchParams({ projectId });
        if (rel) params.set("rel", rel);
        if (inp) params.set("input", inp);
        return api.apiURL(`/minimax/director/novel/image?${params.toString()}`);
    }
    return "";
}

function renderAssetList(host, items, projectId, opts = {}) {
    if (!host) return;
    const kind = opts.kind || "characters";
    const editor = opts.editor;
    host.innerHTML = "";
    for (const a of items || []) {
        const row = document.createElement("div");
        row.className = "h3d-novel-asset";
        const img = document.createElement("img");
        const thumb = assetThumbUrl(projectId, a);
        img.alt = a.name || "";
        img.title = a.inputFile || a.imagePath || a.imageFile || "";
        if (thumb) {
            img.src = thumb;
            img.onerror = () => {
                img.removeAttribute("src");
                img.alt = (a.name || "?").slice(0, 1);
            };
        } else {
            img.alt = (a.name || "?").slice(0, 1);
        }
        const hasImg = !!(a.inputFile || a.imageFile || a.imagePath || a.imageB64);
        const meta = document.createElement("div");
        meta.className = "h3d-novel-asset-meta";
        meta.innerHTML = `<div>${escapeHtml(a.name || "")}</div><div style="opacity:.6">${hasImg ? "已存图" : "仅提示词"}</div>`;
        const delBtn = document.createElement("button");
        delBtn.type = "button";
        delBtn.className = "h3d-btn h3d-novel-asset-del";
        delBtn.textContent = "删除";
        delBtn.title = `从全局库删除「${a.name || ""}」`;
        delBtn.addEventListener("click", async (ev) => {
            ev.preventDefault();
            ev.stopPropagation();
            if (!projectId) {
                editor?._novelSetMsg?.("请先导入项目", true);
                return;
            }
            const label = a.name || a.id || "该资产";
            if (!window.confirm(`确定从全局库删除「${label}」？\n（磁盘参考图也会删除）`)) return;
            try {
                editor?._novelSetMsg?.(`正在删除 ${label}…`);
                const data = await novelApi("/minimax/director/novel/assets/delete", {
                    projectId,
                    kind,
                    assetId: a.id || "",
                    name: a.name || "",
                });
                if (editor) {
                    editor.timeline.novel = slimNovelForTimeline(data.novel || data.project);
                    ensureNovelTimeline(editor.timeline);
                    renderNovelPanel(editor);
                    editor.commit?.(false, { syncTimeline: true });
                }
                editor?._novelSetMsg?.(`已删除：${label}`);
            } catch (err) {
                console.error(err);
                editor?._novelSetMsg?.(String(err?.message || err), true);
            }
        });
        row.appendChild(img);
        row.appendChild(meta);
        row.appendChild(delBtn);
        host.appendChild(row);
    }
    if (!(items || []).length) {
        host.innerHTML = `<div style="opacity:.5;font-size:11px">暂无</div>`;
    }
}

function escapeHtml(s) {
    return String(s || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}

function novelPipelineStep(editor, novel) {
    const chars = novel?.assets?.characters || [];
    const scenes = novel?.assets?.scenes || [];
    const hasAsset = [...chars, ...scenes].some(
        (a) => a && (a.inputFile || a.imageFile || a.imagePath || a.prompt),
    );
    const ch = (novel?.chapters || []).find((c) => c.id === novel.currentChapterId)
        || (novel?.chapters || [])[0];
    const status = String(ch?.status || "");
    const segs = editor?.timeline?.segments || [];
    const loaded = segs.some((s) => s?.novelChapterId || s?.taskType === "novel");
    if (!novel?.projectId) return 1;
    if (!hasAsset) return 2;
    if (!status || status === "pending") return 3;
    if (status === "storyboarded") return 4;
    if (status === "refs_ready" && !loaded) return 5;
    if (loaded || status === "generating" || status === "done") return 5;
    return 3;
}

export function renderNovelPanel(editor) {
    const panel = editor?.novelPanel;
    if (!panel) return;
    const novel = ensureNovelTimeline(editor.timeline);
    const prog = panel.querySelector('[data-r="novel-progress"]');
    const chapters = novel.chapters || [];
    const done = chapters.filter((c) => c.status === "done").length;
    if (prog) {
        prog.textContent = novel.projectId
            ? `${novel.title || novel.projectId} · ${done}/${chapters.length} 章`
            : "未导入";
    }
    const titleEl = panel.querySelector('[data-r="novel-title"]');
    if (titleEl && novel.title && !titleEl.value) titleEl.value = novel.title;

    const settings = novel.settings || {};
    const fillIfIdle = (sel, value) => {
        const el = panel.querySelector(sel);
        if (!el || document.activeElement === el) return;
        if (value == null || Number.isNaN(value)) return;
        el.value = String(value);
    };
    fillIfIdle('[data-r="novel-shot-min"]', settings.shotMin ?? 2);
    fillIfIdle('[data-r="novel-shot-max"]', settings.shotMax ?? settings.maxShotsPerChapter ?? 8);
    fillIfIdle('[data-r="novel-dur-min"]', settings.durationMin ?? 2);
    fillIfIdle('[data-r="novel-dur-max"]', settings.durationMax ?? 12);

    const curStep = novelPipelineStep(editor, novel);
    panel.querySelectorAll(".h3d-novel-step").forEach((el) => {
        const n = Number(el.dataset.step || 0);
        el.classList.toggle("active", n === curStep);
        el.classList.toggle("done", n < curStep);
    });

    const list = panel.querySelector('[data-r="novel-chapters"]');
    if (list) {
        list.innerHTML = "";
        for (const ch of chapters) {
            const row = document.createElement("div");
            row.className = "h3d-novel-ch" + (ch.id === novel.currentChapterId ? " active" : "");
            row.innerHTML = `
              <div title="${escapeHtml((ch.text || "").slice(0, 200))}">${escapeHtml(ch.title || ch.id)}</div>
              <span class="h3d-novel-badge ${ch.status || ""}">${STATUS_LABEL[ch.status] || ch.status || "pending"}</span>
              <span style="opacity:.65;font-size:11px">${ch.shotCount || 0} 镜</span>
            `;
            row.addEventListener("click", () => {
                novel.currentChapterId = ch.id;
                editor.commit?.(false, { syncTimeline: true });
                renderNovelPanel(editor);
            });
            list.appendChild(row);
        }
    }
    renderAssetList(panel.querySelector('[data-r="novel-chars"]'), novel.assets?.characters, novel.projectId, {
        kind: "characters",
        editor,
    });
    renderAssetList(panel.querySelector('[data-r="novel-scenes"]'), novel.assets?.scenes, novel.projectId, {
        kind: "scenes",
        editor,
    });

    const histHost = panel.querySelector('[data-r="novel-op-history"]');
    if (histHost) {
        const hist = Array.isArray(novel.history) ? novel.history.slice(-12).reverse() : [];
        if (!hist.length) {
            histHost.innerHTML = `<div class="h3d-novel-history-item"><span style="opacity:.5">暂无操作记录（分镜/挂图/装载/完成会写入磁盘）</span></div>`;
        } else {
            histHost.innerHTML = hist
                .map((h) => {
                    const at = escapeHtml(String(h.at || "").replace("T", " ").slice(0, 19));
                    const act = escapeHtml(String(h.action || ""));
                    const detail = escapeHtml(String(h.detail || ""));
                    return `<div class="h3d-novel-history-item"><b>${at || act}</b><span>${act}${detail ? ` · ${detail}` : ""}</span></div>`;
                })
                .join("");
        }
    }
}

export function updateNovelPanelVisibility(editor) {
    const panel = editor?.novelPanel;
    if (!panel) return;
    const show = isNovelTask(editor.getTaskKey?.() || editor.taskTypeWidget?.value);
    panel.hidden = !show;
    panel.style.display = show ? "flex" : "none";
    editor.updateNovelDeskMode?.();
    if (show) {
        ensureNovelTimeline(editor.timeline);
        renderNovelPanel(editor);
        // Debounced disk sync when entering novel mode / showing panel
        clearTimeout(editor._novelSyncTimer);
        editor._novelSyncTimer = setTimeout(() => {
            syncNovelFromDisk(editor, { silent: true }).catch(() => {});
        }, 200);
    }
}
