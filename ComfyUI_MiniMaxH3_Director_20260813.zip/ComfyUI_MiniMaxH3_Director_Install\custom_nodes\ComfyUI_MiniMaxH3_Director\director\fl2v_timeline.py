"""First/last-frame (fl2v) timeline → DirectorPlan.

Preferred schema: timeline.shots[] — each shot is one sampling group:
  - startImage (required): image0
  - endImage (optional): image1; missing → i2v
  - durationSec: per-shot length; totalFrames ≈ sum of shot frames

Legacy flat keyframes/segments (isStartFrame / isEndFrame) still supported via
_expand_shots when shots[] is absent.
"""

from __future__ import annotations

import logging
import re
from typing import Any

import torch

from ..lib.image_prep import fit_canvas, fit_video_long_edge, resolve_output_dimensions
from ..lib.task_prompts import resolve_task_key, task_type_option_label, TASK_PROMPT_BY_KEY

log = logging.getLogger("ComfyUI-MiniMaxH3-Director.director.fl2v")

_SCENE_LINE_RE = re.compile(
    r"(?im)^\s*(?:场景名?|地点|场所|LOCATION)\s*[:：]\s*(.+)$"
)
_SCENE_NAME_SPLIT_RE = re.compile(r"[,，、/;；|\s]+")
_SCENE_CHANGE_MARK_RE = re.compile(r"【\s*换场\s*】|换场\s*[:：]")


def _norm_scene_token(text: str) -> str:
    s = (text or "").strip().lower()
    s = re.sub(r"[\s「」『』\"'“”]+", "", s)
    s = re.sub(r"(里|内|中|旁|外|前|后|边|附近|门口|角落|一角)$", "", s)
    return s


def extract_scene_line_names(prompt: str) -> list[str]:
    names: list[str] = []
    for m in _SCENE_LINE_RE.finditer(prompt or ""):
        for n in _SCENE_NAME_SPLIT_RE.split(m.group(1) or ""):
            tok = _norm_scene_token(n)
            if tok and tok not in names:
                names.append(tok)
    return names


def novel_scene_identity(segment) -> str:
    """Stable scene id for continuity: prefer refs/locations/「场景：」 over prose."""
    parts: list[str] = []
    for r in getattr(segment, "refs", None) or []:
        role = str(getattr(r, "role", "") or "").lower()
        if role != "scene":
            continue
        label = _norm_scene_token(str(getattr(r, "label", "") or ""))
        path = str(getattr(r, "image_file", "") or "").strip().replace("\\", "/").lower()
        if path:
            path = path.rsplit("/", 1)[-1]
        if label:
            parts.append(f"label:{label}")
        if path:
            parts.append(f"file:{path}")
    for loc in getattr(segment, "locations", None) or []:
        tok = _norm_scene_token(str(loc))
        if tok:
            parts.append(f"loc:{tok}")
    for name in extract_scene_line_names(str(getattr(segment, "prompt", "") or "")):
        parts.append(f"line:{name}")
    # unique preserve order
    seen: set[str] = set()
    uniq: list[str] = []
    for p in parts:
        if p not in seen:
            seen.add(p)
            uniq.append(p)
    return "|".join(uniq)


def _scene_name_tokens(identity: str) -> set[str]:
    names: set[str] = set()
    for part in (identity or "").split("|"):
        if ":" not in part:
            continue
        kind, val = part.split(":", 1)
        if kind in {"label", "loc", "line"} and val:
            names.add(val)
    return names


def detect_act_boundary(cur, prev) -> bool:
    """True at film/novel act (chapter) boundary — never hard-lock previous unit's last frame."""
    if cur is None:
        return False
    if bool(getattr(cur, "act_boundary", False)):
        return True
    if prev is None:
        return False
    cur_cid = str(getattr(cur, "novel_chapter_id", "") or "").strip()
    prev_cid = str(getattr(prev, "novel_chapter_id", "") or "").strip()
    if cur_cid and prev_cid and cur_cid != prev_cid:
        return True
    cur_shot = getattr(cur, "novel_shot_index", None)
    try:
        if cur_cid and cur_shot is not None and int(cur_shot) == 0:
            return True
    except (TypeError, ValueError):
        pass
    return False


def detect_novel_scene_change(cur, prev) -> bool:
    """True when next shot should NOT hard-lock prev last-frame (换场 / 场景身份变化).

    Policy: hard-lock only when both sides share a non-empty scene identity.
    Missing identity on either side, or explicit 换场 → treat as scene change
    (avoid locking the wrong background).
    Act/chapter boundaries always skip hard-lock (content refs only).
    """
    if prev is None:
        return False
    if detect_act_boundary(cur, prev):
        return True
    cur_prompt = str(getattr(cur, "prompt", "") or "")
    if _SCENE_CHANGE_MARK_RE.search(cur_prompt):
        return True
    a = novel_scene_identity(cur)
    b = novel_scene_identity(prev)
    if a and b:
        na, nb = _scene_name_tokens(a), _scene_name_tokens(b)
        if na and nb:
            # Same place if name sets overlap (教室 vs 教室|file:x)
            return na.isdisjoint(nb)
        # File-only / mixed: any identity string mismatch counts as change
        return a != b
    if bool(a) != bool(b):
        # One shot has explicit scene, the other doesn't → do not assume same room
        return True
    # Both empty: keep chain lock (same-scene default for unlabeled consecutive shots)
    return False

MIN_FL2V_FRAMES = 5
DEFAULT_FL2V_FRAMES = 124
DEFAULT_TOTAL_FRAMES = 240
DEFAULT_FL2V_DURATION_SEC = 5.0
# Match node ``negative_prompt`` default in director_common / director.py.
DEFAULT_FL2V_NEGATIVE = "bad video"


def _duration_to_minimax_frames(seconds: float, fps: float = 24.0) -> int:
    """Official MiniMax formula: max(5, round(a*fps)) then snap to 17k+5."""
    a = max(0.1, float(seconds or 0.1))
    rate = max(1.0, float(fps or 24.0))
    n = max(5, int(round(a * rate)))
    rem = (5 - (n % 17)) % 17
    return n + rem


def _image_ref_from_raw(raw: Any) -> dict[str, Any] | None:
    if raw is None:
        return None
    if isinstance(raw, str):
        path = raw.strip()
        return {"imageFile": path, "imageB64": "", "width": 0, "height": 0} if path else None
    if not isinstance(raw, dict):
        return None
    image_file = str(raw.get("imageFile") or raw.get("image_file") or "").strip()
    image_b64 = str(raw.get("imageB64") or raw.get("image_b64") or "").strip()
    if not image_file and not image_b64:
        return None
    return {
        "imageFile": image_file,
        "imageB64": image_b64,
        "width": int(raw.get("width") or 0),
        "height": int(raw.get("height") or 0),
    }


def _normalize_shots(raw_shots: list | None, *, frame_rate: float = 24.0) -> list[dict[str, Any]]:
    """Normalize explicit shots[] groups. Skips shots without a start image."""
    out: list[dict[str, Any]] = []
    if not raw_shots:
        return out
    cursor = 0
    for i, item in enumerate(raw_shots):
        if not isinstance(item, dict):
            continue
        start = _image_ref_from_raw(item.get("startImage") or item.get("start_image"))
        if start is None:
            continue
        end = _image_ref_from_raw(item.get("endImage") or item.get("end_image"))
        try:
            dur = float(item.get("durationSec") or item.get("duration_sec") or DEFAULT_FL2V_DURATION_SEC)
        except (TypeError, ValueError):
            dur = DEFAULT_FL2V_DURATION_SEC
        dur = max(0.1, dur)
        fc = max(MIN_FL2V_FRAMES, _duration_to_minimax_frames(dur, frame_rate))
        out.append(
            {
                "source_index": i,
                "start": {
                    "imageFile": start["imageFile"],
                    "imageB64": start["imageB64"],
                    "width": start["width"],
                    "height": start["height"],
                    "start": cursor,
                    "length": fc,
                    "frameCount": fc,
                },
                "end": (
                    {
                        "imageFile": end["imageFile"],
                        "imageB64": end["imageB64"],
                        "width": end["width"],
                        "height": end["height"],
                    }
                    if end is not None
                    else None
                ),
                "frameCount": fc,
                "timeline_start": cursor,
                "prompt": (item.get("prompt") or "").strip(),
                "negativePrompt": (
                    item.get("negativePrompt")
                    or item.get("negative_prompt")
                    or DEFAULT_FL2V_NEGATIVE
                ).strip()
                or DEFAULT_FL2V_NEGATIVE,
            }
        )
        cursor += fc
    return out

# Hard locks for every fl2v shot (re-applied after PE). Community cue words:
# MiniMax H3 locks first/last via MiniMaxH3ImageToVideo keyframe latents.
# Prompt text reinforces continuity; avoid Bernini image0/image1 tokens.
FLF_PROMPT_PREFIX = (
    "完全保持首尾帧。"
    "视频第一帧必须与给定首帧画面一致，最后一帧必须与给定尾帧画面一致；"
    "首尾帧是硬锁定关键帧，不是软参考，禁止改动首尾画面、主体外观与机位。"
)
I2V_PROMPT_PREFIX = (
    "完全保持首帧。"
    "视频第一帧必须与给定首帧画面一致；首帧是硬锁定关键帧，不是软参考，禁止改动首帧画面与主体外观。"
)
FLF_PROMPT_SUFFIX = (
    "完全保持首尾帧：开头锁定首帧，结尾锁定尾帧。"
)
I2V_PROMPT_SUFFIX = (
    "完全保持首帧：开头锁定首帧。"
)

# Legacy wraps from earlier builds — strip so re-runs do not stack.
_LEGACY_FL2V_WRAPS = (
    "完全保持首尾帧。"
    "视频开始完全按照image0的构图，不修改，视频结束完全保持image1。"
    "第一帧必须与image0像素级一致，最后一帧必须与image1像素级一致；"
    "image0/image1是固定首尾帧，不是参考图，禁止改动首尾构图、主体外观与机位。",
    "完全保持首帧。"
    "视频开始完全按照image0的构图，不修改。"
    "第一帧必须与image0像素级一致；image0是固定首帧，不是参考图，禁止改动首帧构图与主体外观。",
    "视频开始完全按照image0的构图，不修改，视频结束完全保持image1。",
    "视频开始完全按照image0的构图，不修改，视频结束完全保持image1的构图。",
    "视频结束完全保持image1的构图。",
    "严格要求：第一帧必须与image0一致，最后一帧必须与image1一致；"
    "中间仅做从image0到image1的自然过渡，不得改变首尾构图与主体外观。",
    "视频开始完全按照image0的构图，不修改。"
    "严格要求：第一帧必须与image0一致；后续运动从该首帧自然展开，不得偏离image0的构图与主体外观。",
    "再次强调：开头锁定image0，结尾锁定image1。",
    "再次强调：开头锁定image0。",
)


def _strip_fl2v_wraps(text: str) -> str:
    changed = True
    while changed and text:
        changed = False
        for p in (FLF_PROMPT_PREFIX, I2V_PROMPT_PREFIX, *_LEGACY_FL2V_WRAPS):
            if text.startswith(p):
                text = text[len(p) :].strip()
                changed = True
        for s in (FLF_PROMPT_SUFFIX, I2V_PROMPT_SUFFIX, *_LEGACY_FL2V_WRAPS):
            if text.endswith(s):
                text = text[: -len(s)].strip()
                changed = True
    return text


def _sanitize_fl2v_body(text: str) -> str:
    """Rewrite soft「参考」wording that weakens first/last-frame locking."""
    if not text:
        return text
    replacements = (
        ("reference image0", "image0"),
        ("reference image1", "image1"),
        ("Reference image0", "image0"),
        ("Reference image1", "image1"),
        ("参考图 image0", "image0"),
        ("参考图 image1", "image1"),
        ("参考图image0", "image0"),
        ("参考图image1", "image1"),
        ("参考 image0", "image0"),
        ("参考 image1", "image1"),
        ("参考image0", "image0"),
        ("参考image1", "image1"),
        ("以image0为参考", "完全按照image0"),
        ("以image1为参考", "完全保持image1"),
        ("把image0当作参考", "完全按照image0"),
        ("把image1当作参考", "完全保持image1"),
        ("image0的构图", "image0的画面"),
        ("image1的构图", "image1的画面"),
        ("首尾构图", "首尾画面"),
        ("首帧构图", "首帧画面"),
    )
    out = text
    for old, new in replacements:
        out = out.replace(old, new)
    # Drop duplicated lock lines already present in the body (prefix/suffix will re-add).
    for marker in (
        "完全保持首尾帧。",
        "完全保持首帧。",
        "视频开始完全按照image0的画面，不修改，视频结束完全保持image1的画面。",
        "视频开始完全按照image0的画面，不修改，视频结束完全保持image1。",
        "视频开始完全按照image0的构图，不修改，视频结束完全保持image1。",
        "视频开始完全按照image0的画面，不修改。",
        "视频开始完全按照image0的构图，不修改。",
        "视频结束完全保持image1的画面。",
        "视频结束完全保持image1。",
    ):
        if out.startswith(marker):
            out = out[len(marker) :].strip()
    return out.strip()


def fl2v_prompt_body_only(prompt: str) -> str:
    """Strip hard-lock wraps / PE duplicates; keep only the motion body for UI storage."""
    text = _sanitize_fl2v_body(_strip_fl2v_wraps((prompt or "").strip()))
    text = _strip_chain_opening(text)
    if text.startswith("中间过程："):
        text = text[len("中间过程：") :].strip()
    return text


def reinforce_fl2v_prompt(prompt: str, *, has_end_frame: bool) -> str:
    """Ensure first/last-frame hard constraints wrap the (possibly PE-enhanced) prompt.

    Hard locks are placed *before* the motion body so they survive token truncation.
    """
    text = fl2v_prompt_body_only(prompt)
    prefix = FLF_PROMPT_PREFIX if has_end_frame else I2V_PROMPT_PREFIX
    suffix = FLF_PROMPT_SUFFIX if has_end_frame else I2V_PROMPT_SUFFIX
    if text:
        return f"{prefix}{suffix}中间过程：{text}"
    return f"{prefix}{suffix}"


def is_fl2v_timeline(timeline: dict, task_key: str = "") -> bool:
    mode = str(timeline.get("timelineMode") or "").lower()
    if mode == "fl2v":
        return True
    key = task_key or resolve_task_key(
        (timeline.get("global") or {}).get("taskType") or ""
    )
    return key in {"fl2v", "fl_chain"}


# Chain continuity: model must treat prev last-frame as hard opening (not soft ref).
CHAIN_MARKER = "【链式连贯】"
FL_CHAIN_OPENING = (
    f"{CHAIN_MARKER}"
    "本镜承接上一镜末帧："
    "目标视频在 0.00 秒完整对齐并硬锁定给定首帧（即上一镜最后一帧）；"
    "视频第一帧必须与该首帧画面完全一致——构图、主体外貌服装、关键道具、光线与机位均不得改动；"
    "禁止硬切到无关新场景或新身份；只允许从该首帧起自然推进姿态、表情、站位、景别与运镜。"
)
# i2v / r2v: Picture 1 is the injected prev last-frame.
REF_CHAIN_OPENING = (
    f"{CHAIN_MARKER}"
    "目标视频在 0.00 秒完整参考 <Picture 1>；"
    "<Picture 1> 是上一镜末帧，也是本镜硬锁定首帧/起幅（不是软参考）："
    "开头必须从 <Picture 1> 的构图、主体外貌服装、空间关系与光线起步，再展开后续动作；"
    "跨镜保持人物身份与场景连续过渡，禁止硬切成无关新画面。"
    "若有「主体定义」段，须写明关键主体外观来自 <Picture 1>。"
)
# novel / m2v-style: character sheets stay on Picture 1+; chain is a soft extra ref + post lock.
SOFT_REF_CHAIN_OPENING = (
    f"{CHAIN_MARKER}"
    "本镜承接上一镜人物动作与站位节奏；"
    "人物外貌服装以本镜人物参考图为准；"
    "若本镜附有场景参考图，环境/背景必须以该场景参考图为准，勿漂成无关空间；"
    "禁止无故更换人物身份。"
)
# novel same-scene: hard first_frame lock + strong handoff language (fixes jump cuts).
NOVEL_CHAIN_OPENING = (
    f"{CHAIN_MARKER}"
    "本镜首帧硬锁定上一镜末帧："
    "目标视频在 0.00 秒必须与上一镜最后一帧完全一致（构图、人物站位/姿态、服装、光线与机位）；"
    "只允许从该首帧起自然续演本镜动作与对白，禁止重置站姿、禁止硬切跳变、禁止整段重起幅；"
    "人物外貌服装仍以本镜人物参考图为准；同场景时背景方位与陈设保持连续过渡。"
)
NOVEL_SCENE_CHANGE_CHAIN = (
    f"{CHAIN_MARKER}"
    "【换场】本镜切换到新场景："
    "环境、背景、建筑与陈设必须以本镜场景参考图为准，禁止沿用上一镜的室内外空间；"
    "人物外貌服装保持一致并以人物参考图为准；"
    "可承接人物动作与情绪，但背景必须换成新场景，禁止场景串台。"
)
NOVEL_SPATIAL_MARKER = "【短剧空间】"
NOVEL_SPATIAL_EMPHASIS = (
    f"{NOVEL_SPATIAL_MARKER}"
    "必须写清人物站位与相对方位（画面左/中/右、前景/中景/远景、谁在谁身侧/对面/身后），"
    "以及本镜主动作的起势→过程→落点与身体接触/走位路径；禁止只写抽象情节。"
)
NOVEL_FILM_MARKER = "【电影镜头】"
NOVEL_FILM_EMPHASIS = (
    f"{NOVEL_FILM_MARKER}"
    "按电影语法：景别服务叙事（建立→关系→情绪），运镜有动机，写清景深与主光；"
    "对白克制、留白给表演与声景；禁止竖屏短剧碎切与无意义抖镜。"
)
NOVEL_SCENE_LOCK_MARKER = "【场景锁定】"
NOVEL_AV_SYNC_MARKER = "【声画对齐】"
NOVEL_PACE_MARKER = "【语速节拍】"
NOVEL_FIDELITY_MARKER = "【忠实原文】"
NOVEL_IDENTITY_MARKER = "【身份锁定】"
NOVEL_AV_SYNC_EMPHASIS = (
    f"{NOVEL_AV_SYNC_MARKER}"
    "凡有对白：说话者必须是画面中正在开口的角色，口型与声线跟其人物参考图一致；"
    "说话前写清角色名并绑定对应人物 <Picture N> 与稳定（说n）；"
    "禁止张冠李戴（A 的嘴型配 B 的声线/音色）；画外音须写明嘴唇完全闭合；"
    "台词内容须与分镜提示一致，禁止另编无关对白。"
)
NOVEL_FIDELITY_EMPHASIS = (
    f"{NOVEL_FIDELITY_MARKER}"
    "严格按本镜提示词情节与对白表演，禁止另编主线、偷换冲突、错派角色行为；"
    "未写明的亲密/换装/换地点勿擅自添加；道具与场景名保持与提示一致。"
)
NOVEL_IDENTITY_EMPHASIS = (
    f"{NOVEL_IDENTITY_MARKER}"
    "人物脸型发型服装与对应人物参考图一致；场景建筑陈设与场景参考图一致；"
    "禁止中途换脸换装换背景；禁止把场景参考图画成人物脸。"
)
# Backward-compatible alias
FL_CHAIN_PREFIX = FL_CHAIN_OPENING


def _strip_leading_marked_paragraph(text: str, marker: str) -> str:
    out = text or ""
    if out.startswith(marker):
        nl = out.find("\n")
        return out[nl + 1 :].lstrip() if nl >= 0 else ""
    return out


def _strip_chain_opening(text: str) -> str:
    """Remove prior chain openings so re-reinforce does not stack."""
    out = (text or "").strip()
    if not out:
        return ""
    for block in (
        FL_CHAIN_OPENING,
        REF_CHAIN_OPENING,
        NOVEL_CHAIN_OPENING,
        SOFT_REF_CHAIN_OPENING,
        NOVEL_SCENE_CHANGE_CHAIN,
        NOVEL_SPATIAL_EMPHASIS,
        NOVEL_FILM_EMPHASIS,
        NOVEL_AV_SYNC_EMPHASIS,
    ):
        if out.startswith(block):
            out = out[len(block) :].strip()
    # Drop stacked marker paragraphs if re-reinforcing
    for marker in (
        NOVEL_SCENE_LOCK_MARKER,
        NOVEL_AV_SYNC_MARKER,
        NOVEL_PACE_MARKER,
        NOVEL_FILM_MARKER,
        NOVEL_SPATIAL_MARKER,
        NOVEL_FIDELITY_MARKER,
        NOVEL_IDENTITY_MARKER,
    ):
        out = _strip_leading_marked_paragraph(out, marker)
    # Old short prefix / any paragraph that starts with the marker
    old_short = (
        "【链式连贯】本镜开头紧接上一镜结尾画面，人物外貌服装、场景空间与光线保持连续过渡，"
        "不要硬切成无关新场景。"
    )
    if out.startswith(old_short):
        out = out[len(old_short) :].strip()
    while out.startswith(CHAIN_MARKER):
        nl = out.find("\n")
        if nl < 0:
            return ""
        out = out[nl + 1 :].lstrip()
    return out


def reinforce_fl_chain_prompt(prompt: str, *, has_end_frame: bool, chained: bool) -> str:
    """fl2v/fl_chain with continuity: hard first-frame lock + strong chain opening cue."""
    raw = _strip_chain_opening(prompt or "")
    text = reinforce_fl2v_prompt(raw, has_end_frame=has_end_frame)
    if chained:
        text = _strip_chain_opening(text)
        text = f"{FL_CHAIN_OPENING}\n{text}"
    return text


def reinforce_ref_chain_prompt(
    prompt: str,
    *,
    chained: bool,
    ref_indices: list[int] | None = None,
    video_indices: list[int] | None = None,
    audio_indices: list[int] | None = None,
    soft_chain: bool = False,
) -> str:
    """i2v/r2v with continuity: force <Picture 1> as 0.00s opening frame + media tags.

    soft_chain=True (novel): do not claim/reserve Picture 1 — character sheets stay put.
    """
    from .plan import reinforce_r2v_prompt

    text = _strip_chain_opening(prompt or "").strip() or "生成连贯的电影感画面。"
    idxs = list(ref_indices or [])
    if chained:
        if soft_chain:
            text = f"{SOFT_REF_CHAIN_OPENING}\n{text}"
        else:
            text = f"{REF_CHAIN_OPENING}\n{text}"
            if 0 not in idxs:
                idxs = [0, *idxs]
    return reinforce_r2v_prompt(
        text,
        ref_indices=idxs,
        video_indices=video_indices,
        audio_indices=audio_indices,
    )


def reinforce_novel_prompt(
    prompt: str,
    *,
    chained: bool = False,
    scene_changed: bool = False,
    ref_indices: list[int] | None = None,
    video_indices: list[int] | None = None,
    audio_indices: list[int] | None = None,
    refs: list | None = None,
    duration_sec: float | None = None,
    narrative_mode: str | None = None,
) -> str:
    """Novel short-drama / film: scene lock + A/V sync + pacing; allow explicit 换场."""
    from .plan import reinforce_r2v_prompt
    from .skill_presets import normalize_novel_narrative_mode

    mode = normalize_novel_narrative_mode(narrative_mode)
    text = _strip_chain_opening(prompt or "").strip() or "生成连贯的电影感画面。"
    idxs = list(ref_indices or [])
    if refs is not None and not idxs:
        idxs = [int(getattr(r, "index", 0)) for r in refs if r is not None]

    scene_bits: list[str] = []
    char_bits: list[str] = []
    for r in refs or []:
        if r is None:
            continue
        try:
            pic_n = int(getattr(r, "index", 0)) + 1
        except (TypeError, ValueError):
            continue
        role = str(getattr(r, "role", "") or "").lower()
        label = str(getattr(r, "label", "") or "").strip()
        tag = f"<Picture {pic_n}>"
        if role == "scene":
            scene_bits.append(f"{tag}" + (f"（{label}）" if label else "（场景）"))
        else:
            char_bits.append(f"{tag}" + (f"（{label}）" if label else "（人物）"))

    prefix_parts: list[str] = []
    if chained:
        prefix_parts.append(NOVEL_SCENE_CHANGE_CHAIN if scene_changed else NOVEL_CHAIN_OPENING)
    if scene_bits:
        prefix_parts.append(
            f"{NOVEL_SCENE_LOCK_MARKER}"
            + "、".join(scene_bits)
            + " 是本镜环境/空间锚点：背景、建筑、陈设与场景光线必须跟该图一致；"
            + "禁止漂到其它地点，禁止把场景参考图当成人物脸。"
            + (
                ("人物外貌以 " + "、".join(char_bits) + " 为准。")
                if char_bits
                else "人物外貌以人物参考图为准。"
            )
        )
    elif char_bits:
        prefix_parts.append(
            f"{NOVEL_SCENE_LOCK_MARKER}人物外貌以 " + "、".join(char_bits) + " 为准。"
        )
    if NOVEL_FIDELITY_MARKER not in text:
        prefix_parts.append(NOVEL_FIDELITY_EMPHASIS)
    if NOVEL_IDENTITY_MARKER not in text:
        id_line = NOVEL_IDENTITY_EMPHASIS
        if char_bits or scene_bits:
            bind = []
            if char_bits:
                bind.append("人物=" + "、".join(char_bits))
            if scene_bits:
                bind.append("场景=" + "、".join(scene_bits))
            id_line += "绑定：" + "；".join(bind) + "。"
        prefix_parts.append(id_line)
    if mode == "film":
        if NOVEL_FILM_MARKER not in text:
            prefix_parts.append(NOVEL_FILM_EMPHASIS)
        if NOVEL_SPATIAL_MARKER not in text:
            prefix_parts.append(NOVEL_SPATIAL_EMPHASIS)
    elif NOVEL_SPATIAL_MARKER not in text:
        prefix_parts.append(NOVEL_SPATIAL_EMPHASIS)
    if NOVEL_AV_SYNC_MARKER not in text:
        av = NOVEL_AV_SYNC_EMPHASIS
        if char_bits:
            av += "本镜人物参考：" + "、".join(char_bits) + "。"
        prefix_parts.append(av)
    try:
        dur = float(duration_sec) if duration_sec is not None else 0.0
    except (TypeError, ValueError):
        dur = 0.0
    if dur > 0 and NOVEL_PACE_MARKER not in text:
        if mode == "film":
            prefix_parts.append(
                f"{NOVEL_PACE_MARKER}本镜约 {dur:.1f} 秒（电影节奏）："
                "对白克制，留白给表演与环境声；语速从容，勿赶词；"
                "动作与视线停顿服务潜台词，话说完后嘴唇闭合再接下一动作。"
            )
        else:
            prefix_parts.append(
                f"{NOVEL_PACE_MARKER}本镜约 {dur:.1f} 秒："
                "对白须在此时长内自然说完，语速适中偏从容，勿赶词抢戏，也勿拖长无声空镜；"
                "动作节拍与对白起落同步，话说完后嘴唇闭合再接下一动作。"
            )

    if prefix_parts:
        text = "\n".join(prefix_parts) + "\n" + text
    return reinforce_r2v_prompt(
        text,
        ref_indices=idxs,
        video_indices=video_indices,
        audio_indices=audio_indices,
    )


def _load_image_ref(ref: dict) -> torch.Tensor:
    from .gen_timeline import _load_gen_image_tensor

    return _load_gen_image_tensor(ref)


def _fit_image(
    img: torch.Tensor,
    *,
    width: int,
    height: int,
    output_mode: str,
    ref_max_size: int,
) -> torch.Tensor:
    if img.ndim == 3:
        img = img.unsqueeze(0)
    if output_mode == "fixed":
        return fit_canvas(img, width, height)
    return fit_video_long_edge(img, ref_max_size)


def _build_fl2v_endpoint_source(
    start_img: torch.Tensor,
    end_img: torch.Tensor | None,
    frame_count: int,
) -> torch.Tensor:
    """Build source video with temporal endpoints for Bernini context encoding.

    Prompt/refs alone are soft. Encoding a full-length source whose first frame is
    image0 and last frame is image1 (middle held at image0) gives the model a much
    stronger first/last-frame signal — especially on long later shots.
    """
    from .plan import wan_align_frame_count

    if start_img.ndim == 3:
        start_img = start_img.unsqueeze(0)
    n = wan_align_frame_count(max(MIN_FL2V_FRAMES, int(frame_count)))
    # Hold start through the body (i2v-like), snap last frame to end when present.
    clip = start_img[:1].expand(n, -1, -1, -1).contiguous().clone()
    if end_img is not None:
        if end_img.ndim == 3:
            end_img = end_img.unsqueeze(0)
        # long_edge fit never upscales: different source aspects → different H×W
        # (e.g. start 848×640, end 688×512). Match end to the start canvas.
        h, w = int(clip.shape[1]), int(clip.shape[2])
        if int(end_img.shape[1]) != h or int(end_img.shape[2]) != w:
            log.info(
                "fl2v: fitting end frame %dx%d → %dx%d to match start canvas",
                int(end_img.shape[2]),
                int(end_img.shape[1]),
                w,
                h,
            )
            end_img = fit_canvas(end_img[:1], w, h)
        clip[-1:] = end_img[:1].to(device=clip.device, dtype=clip.dtype)
    return clip


def _unify_fl2v_pair_canvas(
    start_img: torch.Tensor,
    end_img: torch.Tensor | None,
) -> tuple[torch.Tensor, torch.Tensor | None]:
    """Ensure image0/image1 share one HxW after independent long_edge fits."""
    if start_img.ndim == 3:
        start_img = start_img.unsqueeze(0)
    if end_img is None:
        return start_img, None
    if end_img.ndim == 3:
        end_img = end_img.unsqueeze(0)
    h, w = int(start_img.shape[1]), int(start_img.shape[2])
    if int(end_img.shape[1]) != h or int(end_img.shape[2]) != w:
        end_img = fit_canvas(end_img[:1], w, h)
    return start_img, end_img


def _as_bool(value: Any, default: bool = False) -> bool:
    if value is None:
        return default
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "on"}
    return bool(value)


def _normalize_keyframes(raw: list[dict] | None) -> list[dict]:
    out: list[dict] = []
    for idx, item in enumerate(raw or []):
        if not isinstance(item, dict):
            continue
        image_file = (
            (item.get("imageFile") or item.get("image_file") or "").strip()
            or ((item.get("genImage") or {}).get("imageFile") or "").strip()
        )
        if not image_file and not (item.get("imageB64") or item.get("image_b64")):
            continue
        fc = int(
            item.get("frameCount")
            or item.get("frame_count")
            or item.get("length")
            or DEFAULT_FL2V_FRAMES
        )
        fc = max(MIN_FL2V_FRAMES, fc)
        start = max(0, int(item.get("start") or 0))

        if "isEndFrame" in item or "is_end_frame" in item:
            is_end = _as_bool(item.get("isEndFrame", item.get("is_end_frame")))
        elif "breakBefore" in item or "break_before" in item:
            is_end = idx > 0 and not _as_bool(item.get("breakBefore") or item.get("break_before"))
        else:
            is_end = False

        has_start_key = "isStartFrame" in item or "is_start_frame" in item
        is_start = (
            _as_bool(item.get("isStartFrame", item.get("is_start_frame")), True)
            if has_start_key
            else None
        )

        out.append(
            {
                "id": item.get("id") or "",
                "imageFile": image_file,
                "imageB64": item.get("imageB64") or item.get("image_b64") or "",
                "width": int(item.get("width") or (item.get("genImage") or {}).get("width") or 0),
                "height": int(item.get("height") or (item.get("genImage") or {}).get("height") or 0),
                "start": start,
                "length": fc,
                "frameCount": fc,
                "prompt": (item.get("prompt") or "").strip(),
                "negativePrompt": (
                    item.get("negativePrompt")
                    or item.get("negative_prompt")
                    or DEFAULT_FL2V_NEGATIVE
                ).strip()
                or DEFAULT_FL2V_NEGATIVE,
                "isStartFrame": is_start,
                "isEndFrame": is_end,
                "_breakBefore": _as_bool(
                    item.get("breakBefore") or item.get("break_before") or item.get("disconnect")
                ),
            }
        )
    out.sort(key=lambda k: (int(k.get("start") or 0), k.get("id") or ""))
    n = len(out)
    for i, kf in enumerate(out):
        if kf["isStartFrame"] is None:
            # Legacy: only the last continuous end-frame was non-start.
            end_only_last = (
                i > 0
                and i == n - 1
                and not kf.get("_breakBefore")
                and kf.get("isEndFrame")
            )
            kf["isStartFrame"] = not end_only_last
        kf.pop("_breakBefore", None)
    return out


def _shot_sample_frame_count(start_kf: dict, end_kf: dict | None) -> int:
    """Generation length for a start shot.

    Base = start clip length. If the paired end clip is end-only (not a start),
    extend through the end of that end clip's placeholder on the timeline.
    """
    base = max(MIN_FL2V_FRAMES, int(start_kf.get("frameCount") or start_kf.get("length") or DEFAULT_FL2V_FRAMES))
    if end_kf is None:
        return base
    # End clip is also a start → its span belongs to its own shot; only use as image1.
    if end_kf.get("isStartFrame"):
        return base
    start_t = int(start_kf.get("start") or 0)
    end_t = int(end_kf.get("start") or 0) + max(
        MIN_FL2V_FRAMES,
        int(end_kf.get("frameCount") or end_kf.get("length") or DEFAULT_FL2V_FRAMES),
    )
    return max(base, end_t - start_t)


def _expand_shots(keyframes: list[dict]) -> list[dict[str, Any]]:
    """Only isStartFrame clips produce sampling shots.

    Pairing rule:
    - Start+End on the same clip → 首尾同图 (image0=image1=self)
    - Else walk forward until the next Start (exclusive); first End-only is image1
    - Start with no End → i2v; Start+End → fl2v (sample spans both when End-only)
    """
    if not keyframes:
        return []
    shots: list[dict[str, Any]] = []
    n = len(keyframes)
    for i, kf in enumerate(keyframes):
        if not kf.get("isStartFrame"):
            continue
        if kf.get("isEndFrame"):
            # Self-paired 首尾同图: sample this clip alone.
            fc = _shot_sample_frame_count(kf, None)
            shots.append(
                {
                    "source_index": i,
                    "start": kf,
                    "end": kf,
                    "frameCount": fc,
                    "timeline_start": int(kf.get("start") or 0),
                    "prompt": kf.get("prompt") or "",
                    "negativePrompt": kf.get("negativePrompt") or DEFAULT_FL2V_NEGATIVE,
                }
            )
            continue
        end = None
        for j in range(i + 1, n):
            nxt = keyframes[j]
            if nxt.get("isStartFrame"):
                break
            if nxt.get("isEndFrame") and not nxt.get("isStartFrame"):
                end = nxt
                break
        fc = _shot_sample_frame_count(kf, end)
        shots.append(
            {
                "source_index": i,
                "start": kf,
                "end": end,
                "frameCount": fc,
                "timeline_start": int(kf.get("start") or 0),
                "prompt": kf.get("prompt") or "",
                "negativePrompt": kf.get("negativePrompt") or DEFAULT_FL2V_NEGATIVE,
            }
        )
    return shots


def count_fl2v_runnable_shots(timeline: dict) -> int:
    fps = float(timeline.get("frameRate") or 24)
    shots = _normalize_shots(timeline.get("shots"), frame_rate=fps)
    if shots:
        return max(1, len(shots))
    keys = _normalize_keyframes(timeline.get("keyframes") or timeline.get("segments") or [])
    return max(1, sum(1 for k in keys if k.get("isStartFrame")) or 1)


def build_fl2v_director_plan(
    timeline: dict,
    *,
    global_task_type: str,
    global_prompt: str,
    total_frames: int,
    frame_rate: float,
    width: int,
    height: int,
    ref_max_size: int,
):
    from .plan import (
        DirectorPlan,
        SegmentPlan,
        SegmentRef,
        _parse_run_selection,
        _resolve_export_mode,
    )

    global_block = timeline.get("global") or {}
    task_type = global_block.get("taskType") or global_task_type or task_type_option_label(
        TASK_PROMPT_BY_KEY["fl2v"]
    )
    task_key = resolve_task_key(task_type)
    if task_key not in {"fl2v", "fl_chain"}:
        raise ValueError(f"fl2v plan builder received task_key={task_key}")
    chain_mode = task_key == "fl_chain"
    plan_task_key = "fl_chain" if chain_mode else "fl2v"
    err_label = "链式首尾帧" if chain_mode else "fl2v"
    # fl_chain always on; fl2v respects output.continuityEnabled toggle.
    from .segment_continuity import resolve_continuity_settings

    fps = float(timeline.get("frameRate") or frame_rate or 24)
    keyframes = _normalize_keyframes(
        timeline.get("keyframes") or timeline.get("segments") or []
    )
    shots = _normalize_shots(timeline.get("shots"), frame_rate=fps)
    used_explicit_shots = bool(shots)
    if not shots:
        if not keyframes:
            raise ValueError(
                f"{err_label}: 请至少添加一组首尾帧并上传首帧图片。"
            )
        shots = _expand_shots(keyframes)
        if not shots:
            raise ValueError(
                f"{err_label}: 没有可用的首帧组。请添加一组并上传首帧。"
            )

    # runSelection uses shot indices when shots[] is present; else keyframe indices.
    run_count = len(timeline.get("shots") or []) if used_explicit_shots else len(keyframes)
    run_sel = _parse_run_selection(timeline, max(1, run_count))
    if run_sel is not None:
        shots = [s for s in shots if int(s["source_index"]) in run_sel]
        if not shots:
            raise ValueError(
                "MiniMax H3 Director: 「选择运行」已开启，但未勾选任何首尾帧组。"
                "请勾选至少一组再执行。"
            )

    ui_continuity, _ = resolve_continuity_settings(timeline, segment_count=max(2, len(shots)))
    continuity_enabled = bool(chain_mode) or bool(ui_continuity)

    output_block = timeline.get("output") or {}
    out_mode = str(output_block.get("mode") or "long_edge").lower()
    if out_mode not in ("fixed", "long_edge"):
        out_mode = "long_edge"
    first_start = shots[0]["start"]
    src_w = int(first_start.get("width") or 0)
    src_h = int(first_start.get("height") or 0)
    out_w, out_h, ref_max, out_mode = resolve_output_dimensions(
        src_w or int(width or 832),
        src_h or int(height or 480),
        mode=out_mode,
        long_edge=int(
            output_block.get("longEdge")
            or output_block.get("long_edge")
            or ref_max_size
            or 848
        ),
        fixed_width=int(output_block.get("width") or timeline.get("width") or width),
        fixed_height=int(output_block.get("height") or timeline.get("height") or height),
    )

    export_mode = _resolve_export_mode(output_block)
    fallback_prompt = (global_block.get("prompt") or global_prompt or "").strip()
    fallback_negative = (
        global_block.get("negativePrompt")
        or global_block.get("negative_prompt")
        or ""
    ).strip()
    content_total = sum(max(MIN_FL2V_FRAMES, int(s["frameCount"])) for s in shots) or DEFAULT_FL2V_FRAMES
    timeline_total = max(
        MIN_FL2V_FRAMES,
        int(timeline.get("totalFrames") or total_frames or content_total or DEFAULT_TOTAL_FRAMES),
    )
    # Prefer content sum when explicit shots define per-group durations.
    if used_explicit_shots:
        timeline_total = max(MIN_FL2V_FRAMES, content_total)

    segments: list[SegmentPlan] = []
    source_clips: list[torch.Tensor] = []
    plan_index = 0
    for shot_i, shot in enumerate(shots):
        start_kf = shot["start"]
        end_kf = shot["end"]
        start_f = int(shot.get("timeline_start") or 0)
        fc = max(MIN_FL2V_FRAMES, int(shot["frameCount"]))
        user_prompt = (shot.get("prompt") or "").strip() or fallback_prompt
        chained = bool(continuity_enabled and shot_i > 0)
        if continuity_enabled:
            full_prompt = reinforce_fl_chain_prompt(
                user_prompt, has_end_frame=end_kf is not None, chained=chained
            )
        else:
            full_prompt = reinforce_fl2v_prompt(user_prompt, has_end_frame=end_kf is not None)
        shot_negative = (
            (shot.get("negativePrompt") or "").strip()
            or fallback_negative
            or DEFAULT_FL2V_NEGATIVE
        )

        start_ref = {
            "imageFile": start_kf.get("imageFile") or "",
            "imageB64": start_kf.get("imageB64") or "",
        }
        has_start = bool(str(start_ref["imageFile"]).strip() or str(start_ref["imageB64"]).strip())
        if not has_start:
            if continuity_enabled and shot_i > 0:
                # Runtime will overwrite with previous shot's last frame.
                start_img = torch.full((1, out_h, out_w, 3), 0.5, dtype=torch.float32)
            else:
                raise ValueError(
                    f"{err_label}: 第 {shot_i + 1} 组缺少首帧图片。"
                    + ("（链式连贯开启时第 1 组必须上传首帧）" if continuity_enabled else "")
                )
        else:
            start_img = _fit_image(
                _load_image_ref(start_ref),
                width=out_w,
                height=out_h,
                output_mode=out_mode,
                ref_max_size=ref_max,
            )

        end_img = None
        if end_kf is not None:
            end_ref = {
                "imageFile": end_kf.get("imageFile") or "",
                "imageB64": end_kf.get("imageB64") or "",
            }
            end_img = _fit_image(
                _load_image_ref(end_ref),
                width=out_w,
                height=out_h,
                output_mode=out_mode,
                ref_max_size=ref_max,
            )
        start_img, end_img = _unify_fl2v_pair_canvas(start_img, end_img)
        refs: list[SegmentRef] = [
            SegmentRef(index=0, tensor=start_img[:1].clone()),
        ]
        if end_img is not None:
            refs.append(SegmentRef(index=1, tensor=end_img[:1].clone()))

        source_clip = _build_fl2v_endpoint_source(start_img, end_img, fc)
        source_clips.append(source_clip[:1].clone())

        end_f = start_f + fc
        segments.append(
            SegmentPlan(
                index=plan_index,
                start_frame=start_f,
                end_frame=end_f,
                prompt=full_prompt,
                task_type=task_type,
                task_key=plan_task_key,
                use_global=False,
                refs=refs,
                negative_prompt=shot_negative,
                source_clip=source_clip,
            )
        )
        plan_index += 1

    if not segments:
        raise ValueError(
            f"{err_label}: 没有可运行的首尾帧组。请添加一组并上传首帧。"
        )

    source_video = torch.full((len(segments), 16, 16, 3), 0.5, dtype=torch.float32)
    raw = dict(timeline)
    raw["timelineMode"] = "fl2v"
    raw["keyframes"] = keyframes
    raw["totalFrames"] = timeline_total
    if continuity_enabled:
        raw.setdefault("output", {})
        if isinstance(raw["output"], dict):
            raw["output"]["continuityEnabled"] = True

    return DirectorPlan(
        frame_rate=fps,
        total_frames=timeline_total,
        width=out_w,
        height=out_h,
        ref_max_size=ref_max,
        output_mode=out_mode,
        source_width=int(src_w or out_w),
        source_height=int(src_h or out_h),
        global_task_type=task_type,
        global_task_key=plan_task_key,
        global_prompt=fallback_prompt,
        global_refs=[],
        source_video=source_video,
        segments=segments,
        edit_mode="segment",
        raw=raw,
        export_mode=export_mode,
        run_indices=None,
        continuity_enabled=bool(continuity_enabled),
    )
